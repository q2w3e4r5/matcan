#include<p18f2680.h>
#include<usart.h>
#include<string.h>

//#define rs485		//en caso de que tengamos rs485 hay que habilitar la opci�n

#define USART_FLAGS		USART_TX_INT_OFF & USART_RX_INT_ON & USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_CONT_RX & USART_BRGH_HIGH

// 9600 8N1 considerando un clock de 20.000 MHz

#define	OSCFREQ					20				// Oscillator frequency
#define SERIAL_BAUDRATE			115200			// Baud rate de la conexion

#define serial_TxClearFlag() 	PIR1bits.TXIF=0;
#define serial_RxClearFlag() 	PIR1bits.RCIF=0;
#define serial_UsartIsBusy()	(!TXSTAbits.TRMT)			

#define serial_TxFlag()			(PIR1bits.TXIF)
#define serial_RxFlag()			(PIR1bits.RCIF)

#define serial_IsrEnabled()		(PIE1bits.TXIE || PIE1bits.RCIE)

#define serial_TxSource()		(PIE1bits.TXIE && PIR1bits.TXIF )
#define serial_RxSource()		(PIE1bits.RCIE && PIR1bits.RCIF )

#define serial_EnableRs485Reception()	(PORTAbits.RA0=0)
#define serial_EnableRs485Transmition()	(PORTAbits.RA0=1)

#define serial_TxDisableInterrupt()		(PIE1bits.TXIE=0)
#define serial_TxEnableInterrupt()		(PIE1bits.TXIE=1)
#define serial_RxDisableInterrupt()		(PIE1bits.RCIE=0)
#define serial_RxEnableInterrupt()		(PIE1bits.RCIE=1)

void serial_Init(void);
void serial_checkUsartReceptionStatus(void);
void serial_Send(unsigned char data);
void serial_Receive(far volatile unsigned char* serialdata);
