#ifndef __UART_CONST
#define __UART_CONST

#define UART_BAUD_9600		0
#define UART_BAUD_19200		1
#define UART_BAUD_38400		2
#define UART_BAUD_57600		3
#define UART_BAUD_115200	4

extern const unsigned char spbrgH_const[];
extern const unsigned char spbrg_const[];

#endif