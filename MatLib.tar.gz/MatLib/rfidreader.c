#include <p18cxxx.h>
#include "Canopen.h"
#include "rfidreader.h"
#include "..\matcan\user.h"
#include "..\matcan\matcan.h"
#include "uart_const.h"
#include "UARTIntC.h"

#define SM_RFID_SENDREQUEST		0
#define SM_RFID_WAITANSWER		1
#define SM_RFID_PROCESSANSWER	2
#define SM_RFID_VERIFYID		3
#define SM_RFID_TIMEOUT			4

#define WRAPSHORTCOUNTER(ref,count)		((count)<(ref) ? (count)-(ref)+32678 : (count)-(ref))


static unsigned char sm_rfid=SM_RFID_SENDREQUEST;

void rfid_Init()
{
	plc_MM_BYTE(MAP_TPDO0,3)=0xFF;		// No Tag
	
	plc_MM_BYTE(MAP_TPDO0,4)=0;
	plc_MM_BYTE(MAP_TPDO0,5)=0;
	plc_MM_BYTE(MAP_TPDO0,6)=0;
	plc_MM_BYTE(MAP_TPDO0,7)=0;

	sm_rfid=SM_RFID_SENDREQUEST;
}

unsigned char rfid_buffer[100];
unsigned char *rfid_buffer_p;
unsigned char rfid_buffer_count;
unsigned char checksum;
unsigned char expected_len;
unsigned short rfid_timeout;

unsigned long rfid_temp; 

void rfid_Process(unsigned short plc_Clock)
{
	unsigned char d;
	
	switch(sm_rfid)
	{
		case SM_RFID_SENDREQUEST:
			// Vaciamos el buffer
			while(UARTIntGetChar(&d));
		
			rfid_buffer_count=0;
			rfid_buffer_p=rfid_buffer;
			checksum=0;
			
			rfid_timeout=plc_Clock;
			
			// Enviamos un comando select card

			UARTIntPutChar(0xBA);		// Command start
			UARTIntPutChar(0x02);		// Command length
			UARTIntPutChar(0x01);		// Command - Select Card
			UARTIntPutChar(0xB9);		// CheckSUM

			sm_rfid=SM_RFID_WAITANSWER;
			break;
			
		case SM_RFID_WAITANSWER:

			if(UARTIntGetChar(&d)){
				rfid_timeout=plc_Clock;
				
				// Primero esperamos un 0xBD como inicio de respuesta
				if (rfid_buffer_count==0u) 
				{
					if (d!=0xBD)	break;
				}
				
				// Si ya recibimos el inicio, aceptamos el byte
				if (rfid_buffer_count==1u)
				{
					expected_len=d;
				}
					
				*rfid_buffer_p++=d;
				
				// El comando esta completo
				if (rfid_buffer_count>=expected_len+1)
				{
					// El checksum verifica
					if (checksum==d) 
					{
						sm_rfid=SM_RFID_PROCESSANSWER;
						break;
					} else {
						sm_rfid=SM_RFID_TIMEOUT;
					}
				}
				
				// Calculamos el checksum;
				checksum^=d;
				rfid_buffer_count++;
				if (rfid_buffer_count==sizeof(rfid_buffer))
				{
					sm_rfid=SM_RFID_TIMEOUT;
				}
			}
			
			// Verificamos que no haya un timeout
			if (WRAPSHORTCOUNTER(rfid_timeout, plc_Clock)>150u)
			{
				sm_rfid=SM_RFID_TIMEOUT;
				break;
			}
			
			break;

		case SM_RFID_PROCESSANSWER:
			
			// Tenemos la respuesta en el buffer
			if (rfid_buffer[3]==0u || rfid_buffer[3]==0x0Au ) 
			{
				if (rfid_buffer[1]==8u) 
				{	// answer len=8	- Aceptamos MiFare standard y pro
					plc_MM_BYTE(MAP_TPDO0,4)=rfid_buffer[4];
					plc_MM_BYTE(MAP_TPDO0,5)=rfid_buffer[5];
					plc_MM_BYTE(MAP_TPDO0,6)=rfid_buffer[6];
					plc_MM_BYTE(MAP_TPDO0,7)=rfid_buffer[7];
					
					sm_rfid=SM_RFID_VERIFYID;
					break;
				}
			}
			sm_rfid=SM_RFID_TIMEOUT;
			
			break;
			
		case SM_RFID_VERIFYID:
			d=0;		
			
			rfid_temp=rfid_buffer[4];
			rfid_temp<<=8;
			rfid_temp|=rfid_buffer[5];
			rfid_temp<<=8;
			rfid_temp|=rfid_buffer[6];
			rfid_temp<<=8;
			rfid_temp|=rfid_buffer[7];

			while(d<rfid_IDCount) {
				if (rfid_temp==rfid_IDList[d]) break;
				d++;				
			}			

			if (d<rfid_IDCount) 
				plc_MM_BYTE(MAP_TPDO0,3)=d;			// Tag ID found
			else 
				plc_MM_BYTE(MAP_TPDO0,3)=0xFE;		// Tag ID not found


			sm_rfid=SM_RFID_SENDREQUEST;
			break;

		case SM_RFID_TIMEOUT:
			// Limpiamos el area de memoria y volvemos a intentar
		
			plc_MM_BYTE(MAP_TPDO0,3)=0xFF;		// No Tag

			plc_MM_BYTE(MAP_TPDO0,4)=0;
			plc_MM_BYTE(MAP_TPDO0,5)=0;
			plc_MM_BYTE(MAP_TPDO0,6)=0;
			plc_MM_BYTE(MAP_TPDO0,7)=0;
			
			sm_rfid=SM_RFID_SENDREQUEST;
			break;
	}
}