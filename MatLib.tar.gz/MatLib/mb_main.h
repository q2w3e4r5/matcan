// Calculamos el CRC segun MODBUS

void CalcCRC16(unsigned char *msg, unsigned short usDataLen);
#define TO_UINT(a,b)	((((unsigned int)a)<<8)+b)

#define MB_BUFFER_SIZE 50							// Tama�o del maximo comando modbus
#define MB_CONSTRESULT	7*OSCFREQ/BAUDRATE			// Formula:  0xFFFF - 7*f/baud
#define IDLETMRCONST	(0xFFFF-MB_CONSTRESULT)

extern unsigned char MB_ans[MB_BUFFER_SIZE];		// Respuesta Modbus
extern unsigned char MB_ans_len;					// Cantidad de bytes en la respuesta

extern rom unsigned char mb_Type;
extern rom unsigned char mb_NodeId;

extern volatile unsigned char MB_waiting;					// hay un comando o respuesta en espera
extern volatile unsigned char MB_busy;						// Modbus esta esperando una respuesta
extern volatile unsigned char MB_timeout;					// Indica que hubo un timeout en la recepcion de la respuesta

//////////////////////////////////////////////
//
//  Comandos a utilizar el programa principal
//
void MB_Init();
void MB_Process(unsigned short plc_Clock);

void MB_SendAnsByte(void);
unsigned char *MB_GetAnswer(void);					// Devuelve el vector con la ultima respuesta
unsigned char MB_WaitAnswer(void);					// Se bloquea hasta la respuesta 0 OK 1 Timeout
int MB_HasAnswerOK(void);
int MB_AnswerOK(void);								// Indica si hubo una respuesta al ultimo comando

// Estas funciones envian el comando modbus

#define MB_ReadCoilStatus(addr, start, count) 			MB_CommandRead(MB_READCOILSTATUS, addr, start, count);
#define MB_ReadInputStatus(addr, start, count)  		MB_CommandRead(MB_READINPUTSTATUS, addr, start, count);
#define MB_ReadHoldingRegister(addr, start, count) 		MB_CommandRead(MB_READHOLDINGREGISTER, addr, start, count);
#define MB_ReadInputRegisters(addr, start, count)		MB_CommandRead(MB_READINPUTREGISTERS, addr, start, count);
void MB_ForceSingleCoil(unsigned char addr, unsigned short start, unsigned char value);
void MB_PresetSingleRegister(unsigned char addr, unsigned short start, unsigned int value);
void MB_ForceMultipleCoils(unsigned char addr, unsigned short start, unsigned char count, unsigned char* data);
void MB_PresetMultipleRegisters(unsigned char addr, unsigned short start, unsigned char count, unsigned char *data);

/////////////////////////
// MAPAS QUE SE DEBEN DEFINIR EN EL PROGRAMA PRINCIPAL
//
unsigned char MB_get00000(unsigned int bit_p);							// Salidas D		1 bit
unsigned char MB_get10000(unsigned int bit_p);							// Entradas	D		1 bit
unsigned int MB_get30000(unsigned int word_p);							// Entradas A		16bits
unsigned int MB_get40000(unsigned int word_p);							// Entradas D		16bits
void MB_set00000(unsigned int bit_p, unsigned char value);				// Salidas D		1 bit
void MB_set40000(unsigned int word_p,unsigned int value);				// Salidas A		16 bits


//////////////////////////////////////////////
//
//  Comandos internos
//
int MB_CheckCRC(unsigned char *buffer, unsigned char *lastpos);
void MB_AddCRC(unsigned char *buffer, unsigned char *lastpos);

void 			MB_SendEchoAns(void);						// Envia una respuesta modbus copiando el comando
void 			MB_SendAns(void);							// Envia una respuesta modbus 
unsigned char 	MB_SendError(unsigned char err);			// Envia un error Modbus
void 			MB_SendCmd(void);							// Enviamos el comando

void MB_CommandRead(unsigned char cmd, unsigned char addr, unsigned short start, unsigned short count);

void MB_ReadInputs();											// Lee inputs 			10000s [son bits]
void MB_ReadCoils();											// Lee Salidas			00000s [son bits]
void MB_WriteCoils();											// Escribe salidas		00000s [son bits]
void MB_ReadHolding();											// Lee registros 		40000s [son 16bits]
void MB_ReadInReg();											// Lee Registros	    30000s [son 16bits]
void MB_WriteRegisters();										// Escrib multregistros 40000s [son 16bits]

#define MB_READCOILSTATUS			0x01
#define MB_READINPUTSTATUS			0x02
#define MB_READHOLDINGREGISTER		0x03
#define MB_READINPUTREGISTERS		0x04
#define MB_FORCESINGLECOIL			0x05
#define MB_PRESETSINGLEREGISTER		0x06
#define MB_READEXCEPTIONSTATUS		0x07
#define MB_FORCEMULTIPLECOILS		0x0F
#define MB_PRESETMULTIPLEREGISTERS	0x10

#define MB_DISABLED 0u
#define MB_MASTER	1u
#define MB_SLAVE	2u









/*
EJEMPLO DE MAPA MODBUS
En este mapa segun que registro nos preguntan contestamos la variable adecuada.
En los otros casos el valor viene en value

unsigned int MB_get40000(int word_p)
{
	if (word_p==0) return distancia;
	if (word_p==1) return PORTC & 0x0F;
	if (word_p==2) return temperatura;
	if (word_p==3) return ee_ReadWord(0);
	if (word_p==4) return ee_ReadWord(2);
	if (word_p==5) return ee_ReadWord(4);
	if (word_p==6) return ee_ReadWord(6);
	if (word_p==7) return ee_ReadWord(8);
}
*/
