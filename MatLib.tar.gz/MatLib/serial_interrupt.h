extern unsigned char (*serialReceiveEvent)(unsigned char serialdata);

void serialint_Init(void);
unsigned char serialint_Isr(void);


void serialint_TxClear(void);
void serialint_RxClear(void);

unsigned char serialint_DataAvailable(void);
unsigned char serialint_txQueueCount(void);

void serialint_Send(unsigned char serialdata);
void serialint_Receive(far unsigned char *serialdata);

void serialint_RxCopyBuffer(unsigned char *dest, unsigned char *len);
void serialint_RxCopyBufferDelim(unsigned char *dest, unsigned char *len, unsigned char delim);
void serialint_TxCopyBuffer(unsigned char *src, unsigned char len);

void serialint_PrivateReceive(void);
void serialint_PrivateSend(void);
