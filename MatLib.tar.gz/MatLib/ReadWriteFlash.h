unsigned char ReadFromProgramMemory(unsigned short addr);
unsigned char WriteToProgramMemory(unsigned short addr, unsigned char* data, unsigned int memsize);
