#include "..\matcan\matcan.h"
#include "uart_const.h"


/*
Estas son si BRG16 esta apagado
#if MAT_OSC_FREQ == 40
	const unsigned char spbrgH_const[]= 	{ 0,1,1,1,1 };
	const unsigned char spbrg_const[]=  	{ 64, 129, 64, 42, 20  };
#elif MAT_OSC_FREQ == 20
	const unsigned char spbrgH_const[]= 	{ 1,1,1,1,1 };
	const unsigned char spbrg_const[]=  	{ 129, 64, 31, 20, 9  };
#elif MAT_OSC_FREQ == 10
	const unsigned char spbrgH_const[]= 	{ 1,1,1,1,1 };
	const unsigned char spbrg_const[]=  	{ 64, 31, 15, 9, 4  };
#else
   #error define_CO_OSCILATOR_FREQ MAT_OSC_FREQ not supported
#endif
*/

// 9600, 19200, 38400, 57600, 115200

#if MAT_OSC_FREQ == 40
	const unsigned char spbrgH_const[]= 	{ 0,0,0,1,1 };
	const unsigned char spbrg_const[]=  	{ 255, 129, 64, 172, 85  };
	
#else
   #error define_CO_OSCILATOR_FREQ MAT_OSC_FREQ not supported
#endif


#if MAT_OSC_FREQ>20				
	#pragma config OSC = HSPLL				// En el caso de 10Mhz x 4 = 40Mhz
#else
	#pragma config OSC = HS					// En el caso de 20Mhz
#endif
