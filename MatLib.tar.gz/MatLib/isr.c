#include "isr.h"

void isr_high_DUMMY(void);
void isr_low_DUMMY(void);

#pragma code high_vector = 0x1408
void interrupt_at_high_vector (void)
{
	_asm goto isr_high_DUMMY _endasm
}
#pragma code

#pragma code low_vector = 0x1418
void interrupt_at_low_vector (void)
{
	_asm goto isr_low_DUMMY _endasm
}
#pragma code

#pragma interrupt isr_high_DUMMY
void isr_high_DUMMY(void)
{
	isr_high();
}

#pragma interruptlow isr_low_DUMMY
void isr_low_DUMMY(void)
{
	isr_low(); 
}

