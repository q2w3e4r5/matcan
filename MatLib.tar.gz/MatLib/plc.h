#define STACK_OPCODE_TYPE			unsigned char
#define STACK_POS_TYPE				int
#define PROGRAM_TYPE				unsigned char

#define PLCPROGRAMSIZE				248

//
//	Cada instruccion tiene la siguiente estructura
//	OPCODE    [A:B]
//
//	Instruction codes

#define IL_B		0b10000000u			// 0x80
#define IL_P		0b01000000u			// 0x40
#define IL_N		0b00100000u			// 0x20

#define IL_BASEOPCODE (0xFF-IL_B-IL_P-IL_N)	// 0b00011111

#define IL_END		0u					// 	Sin parametros

#define IL_LD		1u					//  load in stack
#define IL_ST		2u					//  store
#define IL_S		3u					//	set
#define IL_R		4u					//	reset
#define IL_MPS		5u					//  Push into stack
#define IL_MPP		6u					//  Pop from stack
#define IL_MRD		7u					//  Pop y push

#define IL_AND		8u					//	and
#define IL_OR		9u					//	or
#define	IL_XOR		10u					//	xor

#define	IL_ADD		11u					//	add
#define	IL_SUB		12u					//	sub

#define	IL_GT		13u					//	mayor
#define	IL_GE		14u					//	mayor o igual
#define	IL_EQ		15u					//	igual

#define IL_JMP		16u					//  Cambiar el Program Counter
#define IL_JMPC		17u					//  Cambiar el Program Counter / Condicional
#define IL_CAL		18u					//  Llama a funciones preprogramadas

#define IL_CSET	19u					// hace set el anterior es 1


#define IL_LE		(IL_GT  | IL_N)		//	menor o igual (!mayor)
#define IL_LT		(IL_GE	| IL_N)		//  menor (!GE)
#define IL_NE		(IL_EQ  | IL_N)		//  no igual

#define IL_LDN		(IL_LD  | IL_N)		//  loadnot in stack
#define IL_STN		(IL_ST  | IL_N)		//  store not

#define	IL_ANDN		(IL_AND | IL_N)		//	andn
#define	IL_ORN		(IL_OR  | IL_N)		// orn
#define	IL_XORN		(IL_XOR | IL_N)		//	xorn

#define IL_ANDP		(IL_AND | IL_P)		//	and
#define IL_ORP		(IL_OR  | IL_P)		//	or
#define	IL_XORP		(IL_XOR | IL_P)		//	xor

#define IL_ANDB		(IL_AND | IL_B)		// and dos lineas stack
#define IL_ORB		(IL_OR  | IL_B)		// or dos lineas stack
#define IL_XORB		(IL_XOR | IL_B)		// xor dos lineas stack

#define IL_ADDB	(IL_ADD | IL_B)

// El plc siempre trabaja con datos de 16bits
//
//
// ***  Data Format ***

// Generic	TTDD DDDD DDDD DDDD
// Bit/Coil	00XX XXXX XXXX XBBB		<< Coil Number
// Byte     01XX XXXX XXXX XXXX		<< Byte 8-bits
// word		10XX XXXX XXXX XXXX		<< Word 16-bits
// RESERVED 11XX XXXX XXXX XXXX		<< Reservado

// *** OpCode Format ***

// MMMCCCCC
// 1xxCCCCC  << B Modifier
// x1xCCCCC  << P Modifier
// xx1CCCCC  << N Modifier

#define IL_DATATYPE_SHIFT	14
#define IL_DATABIT			0b00
#define IL_DATABYTE			0b01
#define IL_DATAWORD			0b10
#define IL_DATACONST		0b11

#define IL_BIT				(IL_DATABIT<<6)
#define IL_BYTE				(IL_DATABYTE<<6)
#define IL_WORD				(IL_DATAWORD<<6)
#define IL_CONST			(IL_DATACONST<<6)


// Funciones avanzadas
// Devuelve 1 si el programa se acabo

unsigned char plc_Process(PROGRAM_TYPE *program, unsigned char *pc, unsigned char programSize, unsigned char *memory, unsigned short clock);
