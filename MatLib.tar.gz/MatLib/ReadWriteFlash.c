#include <p18cxxx.h>
#include "..\mLoader\mLoaderProgram.h"

unsigned char ReadFromProgramMemory(unsigned short addr) 
{ 
	volatile unsigned char temp; 
	TBLPTR = addr;
	EECON1bits.EEPGD = 1; 
	EECON1bits.CFGS = 0; 
	EECON1bits.RD = 1;
	_asm
		TBLRDPOSTINC
	_endasm
	temp = TABLAT;
	return temp;
}

unsigned char WriteBootloader()
{
	int i;
	int offset = 0x40;
	char temp[64];

	// Write Program
	while (blProgramSize - offset > 0u)
	{
		for (i=0; i<64;i++)
		{
			temp[i] = bootloader_Program[i+offset];
		}

		while (EECON1bits.WR == 1u);
	
		// Erase
		TBLPTR = offset;
		EECON1bits.EEPGD = 1;
		EECON1bits.CFGS = 0;
		EECON1bits.WREN = 1;
		EECON1bits.FREE = 1;
		INTCONbits.GIE = 0;
		EECON2 = 0x55;
		EECON2 = 0xAA;
		EECON1bits.WR = 1;
		Nop();
	
		// Prepare
		INTCONbits.GIE = 1;
		EECON1bits.WREN = 0;

		for (i=0; i< 64; i++)
		{
			// Write
			TABLAT = temp[i];
			_asm
				TBLWTPOSTINC
			_endasm
			
			if(((i + 1) % 8) == 0)
			{
	 			TBLPTR -= 8;
	 			EECON1bits.EEPGD = 1; // ...write the holding registers to flash
	 			EECON1bits.CFGS = 0;
	 			EECON1bits.WREN = 1;
	 			EECON1bits.FREE = 0;
	 			INTCONbits.GIE = 0;
	 			EECON2 = 0x55;
	 			EECON2 = 0xAA;
	 			EECON1bits.WR = 1;
	 			Nop();
	 			INTCONbits.GIE = 1;
	 			EECON1bits.WREN = 0;
	 			TBLPTR += 8;
			}
		}

		offset += 64;
	}

	// Goto 0x40 en el lugar 0x20 (por versiones viejos)
	for (i=0; i<64;i++)
	{
		if (i == 0x20) temp[i] = 0x20;
		else if (i==0x21) temp[i] = 0xEF;
		else if (i==0x22) temp[i] = 0x00;
		else if (i==0x23) temp[i] = 0xF0;
		else temp[i] = ReadFromProgramMemory(i);
	}

	while (EECON1bits.WR == 1u);

	// Erase
	TBLPTR = 0;
	EECON1bits.EEPGD = 1;
	EECON1bits.CFGS = 0;
	EECON1bits.WREN = 1;
	EECON1bits.FREE = 1;
	INTCONbits.GIE = 0;
	EECON2 = 0x55;
	EECON2 = 0xAA;
	EECON1bits.WR = 1;
	Nop();

	// Prepare
	INTCONbits.GIE = 1;
	EECON1bits.WREN = 0;

	for (i=0; i< 64; i++)
	{
		// Write
		TABLAT = temp[i];
		_asm
			TBLWTPOSTINC
		_endasm
		
		if(((i + 1) % 8) == 0)
		{
 			TBLPTR -= 8;
 			EECON1bits.EEPGD = 1; // ...write the holding registers to flash
 			EECON1bits.CFGS = 0;
 			EECON1bits.WREN = 1;
 			EECON1bits.FREE = 0;
 			INTCONbits.GIE = 0;
 			EECON2 = 0x55;
 			EECON2 = 0xAA;
 			EECON1bits.WR = 1;
 			Nop();
 			INTCONbits.GIE = 1;
 			EECON1bits.WREN = 0;
 			TBLPTR += 8;
		}
	}
}