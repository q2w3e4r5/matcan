#include<stdio.h>
#include "can_drv.h"
#include<p18cxxx.h>

#ifndef CAN_OSCILATOR_FREQ
   #define CAN_OSCILATOR_FREQ     20 //(4, 8, 16, 20, 24, 32 or 40)
#endif

/*******************************************************************************
   CAN bit rates - Registers setup
*******************************************************************************/
rom struct{
   unsigned char BRP;         //(1...64)Baud Rate Prescaler
   unsigned char SJW;         //(1...4) SJW time
   unsigned char PROP;        //(1...8) PROP time
   unsigned char PhSeg1;      //(1...8) Phase Segment 1 time
   unsigned char PhSeg2;      //(1...8) Phase Segment 2 time
} CAN_BitRateData[8] =
#if CAN_OSCILATOR_FREQ == 4
  {{10,  1, 8, 8, 3}, //CAN=10kbps
   {5,   1, 8, 8, 3}, //CAN=20kbps
   {2,   1, 8, 8, 3}, //CAN=50kbps
   {1,   1, 5, 8, 2}, //CAN=125kbps
   {1,   1, 2, 4, 1}, //CAN=250kbps
   {1,   1, 1, 1, 1}, //CAN=500kbps
   {1,   1, 1, 1, 1}, //CAN=800kbps     //Not possible
   {1,   1, 1, 1, 1}};//CAN=1000kbps    //Not possible
#elif CAN_OSCILATOR_FREQ == 8
  {{25,  1, 5, 8, 2}, //CAN=10kbps
   {10,  1, 8, 8, 3}, //CAN=20kbps
   {5,   1, 5, 8, 2}, //CAN=50kbps
   {2,   1, 5, 8, 2}, //CAN=125kbps
   {1,   1, 5, 8, 2}, //CAN=250kbps
   {1,   1, 2, 4, 1}, //CAN=500kbps
   {1,   1, 1, 2, 1}, //CAN=800kbps
   {1,   1, 1, 1, 1}};//CAN=1000kbps
#elif CAN_OSCILATOR_FREQ == 16
  {{50,  1, 5, 8, 2}, //CAN=10kbps
   {25,  1, 5, 8, 2}, //CAN=20kbps
   {10,  1, 5, 8, 2}, //CAN=50kbps
   {4,   1, 5, 8, 2}, //CAN=125kbps
   {2,   1, 5, 8, 2}, //CAN=250kbps
   {1,   1, 5, 8, 2}, //CAN=500kbps
   {1,   1, 3, 4, 2}, //CAN=800kbps
   {1,   1, 2, 3, 2}};//CAN=1000kbps
#elif CAN_OSCILATOR_FREQ == 20
  {{50,  1, 8, 8, 3}, //CAN=10kbps
   {25,  1, 8, 8, 3}, //CAN=20kbps
   {10,  1, 8, 8, 3}, //CAN=50kbps
   {5,   1, 5, 8, 2}, //CAN=125kbps
   {2,   1, 8, 8, 3}, //CAN=250kbps
   {1,   1, 8, 8, 3}, //CAN=500kbps
   {1,   1, 8, 8, 3}, //CAN=800kbps     //Not possible
   {1,   1, 3, 4, 2}};//CAN=1000kbps
#elif CAN_OSCILATOR_FREQ == 24
  {{63,  1, 8, 8, 2}, //CAN=10kbps
   {40,  1, 4, 8, 2}, //CAN=20kbps
   {15,  1, 5, 8, 2}, //CAN=50kbps
   {6,   1, 5, 8, 2}, //CAN=125kbps
   {3,   1, 5, 8, 2}, //CAN=250kbps
   {2,   1, 3, 6, 2}, //CAN=500kbps
   {1,   1, 5, 7, 2}, //CAN=800kbps
   {1,   1, 3, 6, 2}};//CAN=1000kbps
#elif CAN_OSCILATOR_FREQ == 32
  {{64,  1, 8, 8, 8}, //CAN=10kbps
   {50,  1, 5, 8, 2}, //CAN=20kbps
   {20,  1, 5, 8, 2}, //CAN=50kbps
   {8,   1, 5, 8, 2}, //CAN=125kbps
   {4,   1, 5, 8, 2}, //CAN=250kbps
   {2,   1, 5, 8, 2}, //CAN=500kbps
   {2,   1, 3, 4, 2}, //CAN=800kbps
   {2,   1, 2, 3, 2}};//CAN=1000kbps
#elif CAN_OSCILATOR_FREQ == 40
  {{50,  1, 8, 8, 3}, //CAN=10kbps      //Not possible
   {50,  1, 8, 8, 3}, //CAN=20kbps
   {25,  1, 5, 8, 2}, //CAN=50kbps
   {10,  1, 5, 8, 2}, //CAN=125kbps
   {5,   1, 5, 8, 2}, //CAN=250kbps
   {2,   1, 8, 8, 3}, //CAN=500kbps
   {1,   1, 8, 8, 8}, //CAN=800kbps
   {2,   1, 2, 5, 2}};//CAN=1000kbps
#else
   #error define_CO_OSCILATOR_FREQ CO_OSCILATOR_FREQ not supported
#endif

unsigned char filterBusy=0;

void can_SetBaudRate(unsigned char CAN_BitRate)
{
   BRGCON1 = ((CAN_BitRateData[CAN_BitRate].SJW-1) <<6 ) | (CAN_BitRateData[CAN_BitRate].BRP-1);
   BRGCON2 = 0x80 | ((CAN_BitRateData[CAN_BitRate].PhSeg1-1)<<3) | (CAN_BitRateData[CAN_BitRate].PROP-1);
   BRGCON3 = (CAN_BitRateData[CAN_BitRate].PhSeg2-1);
}

void can_DrvInit(void)
{
//se setea el puerto B para que funcione CAN
	TRISBbits.TRISB3=1;
	TRISBbits.TRISB2=0;

	can_H_ChangeModeConfig();			//se pasa al modo de configuraci�n
	while(!can_InConfigMode()); 		//se espera a que cambie
 
// Se selecciona el modo 0
	ECANCONbits.MDSEL1=0;
	ECANCONbits.MDSEL0=0;
	
//Se setea el registro CIOCON Averiguar el funcionamiento
//se setea para que se coloque CANtx a VDD cuando est� recessive
	CIOCON=0b00100000;					// 0x20			

//Se inicializan todas las interrupciones
	PIE3=0b00111111;					
									/* 	b7=IRXIE interrupci�n por mensajes inv�lidos
										b6=WAKIE interrupci�n por wake up
										b5=ERRIE interrupci�n por error del bus can
										b4=TXB2IE interrupci�n por Tx2
										b3=TXB1IE interrupcion por Tx1
										b2=TXB0IE interrupcion por Tx0
										b1=RXB1IE interrupci�n por Rx1
										b0=RXB0IE interrupci�n por Rx0 
									*/

//Se selecciona la prioridad de las interrupciones

	IPR3=0xFF;						// Todas en alta prioridad
}

char can_RxFilterAvailable(void)
{
	if(filterBusy<=FILTERQTY)
	{
		filterBusy++;
		return (filterBusy);		//retorna desde 1 hasta 5, significa que el filtro 0 es para nmt siempre
	}
	else return -1;
}

void can_RxMessageType(unsigned char type)		//define el tipo de mensages que se van a recibir(st�ndar, extended....)
{
//CAN_RXANY				1		// All including errors
//CAN_RXONLYEXTENDED	2		// Only extended
//CAN_RXONLYSTANDARD	3		// Only standard
//CAN_RXVALIDEXIDEN		4		// Valid according to EXIDEN in filters
	switch(type){
		case CAN_RXANY:
			RXB0CONbits.RXM1=1;		RXB0CONbits.RXM0=1;	
			RXB1CONbits.RXM1=1;		RXB1CONbits.RXM0=1;
			break;
		case CAN_RXONLYEXTENDED:
			RXB0CONbits.RXM1=1;		RXB0CONbits.RXM0=0;	
			RXB1CONbits.RXM1=1;		RXB1CONbits.RXM0=0;
			break;
		case CAN_RXONLYSTANDARD:
			RXB0CONbits.RXM1=0;		RXB0CONbits.RXM0=1;	
			RXB1CONbits.RXM1=0;		RXB1CONbits.RXM0=1;
			break;
		case CAN_RXVALID:
			RXB0CONbits.RXM1=0;		RXB0CONbits.RXM0=0;	
			RXB1CONbits.RXM1=0;		RXB1CONbits.RXM0=0;
			break;
	}
}	

//				BIT7	BIT6	BIT5	BIT4	BIT3	BIT2	BIT1	BIT0
//////////////////////////////////////////////////////////////////////////////////
// TXBnSIDL		SID2	SID1	SID0	----	EXIDE	----	----	----
// exide=1		EID20	EID19	EID18	----	EXIDE	----	EID17	EID16

// TXBnSIDH		SID10   SID9	SID8	SID7	SID6	SID5	SID4	SID3
// exide=1		EID28	EID27	EID26	EID25	EID24	EID23	EID22	EID21

// TXBnEIDH		EID15	EID16	EID13	EID12	EID11	EID10	EID9	EID8
// TXBnEIDL		EID7	EID6	EID5	EID4	EID3	EID2	EID1	EID0

void can_TxSetId(unsigned char buffNum , unsigned long id, unsigned char extended)		//se setea el id de los mensajes que se van a transmitir
{
	if (!extended){						// No es id extendido
		switch(buffNum) 	{	
			case 0:
				TXB0SIDL=(id & 0x7)<<5;					// El EXIDE queda en cero
				TXB0SIDH=(id >> 3) & 0xFF;
				break;
			case 1:
				TXB1SIDL=(id & 0x7)<<5;					// El EXIDE queda en cero
				TXB1SIDH=(id >> 3) & 0xFF;
				break;
			case 2:
				TXB2SIDL=(id & 0x7)<<5;					// El EXIDE queda en cero
				TXB2SIDH=(id >> 3) & 0xFF;
				break;
		}
	} else {							// Es id extendido
		switch(buffNum) 	{	
			case 0:
				TXB0SIDL=((id>>13)&0xE0) | 0x8 | ((id>>16)&0x3);		// Prendemos EXIDE
				TXB0SIDH=(id>>21)&0xFF;
				TXB0EIDH=(id>>8) & 0xFF;
				TXB0EIDL=id & 0xFF;
				break;
			case 1:
				TXB1SIDL=((id>>13)&0xE0) | 0x8 | ((id>>16)&0x3);		// Prendemos EXIDE
				TXB1SIDH=(id>>21)&0xFF;
				TXB1EIDH=(id>>8) & 0xFF;
				TXB1EIDL=id & 0xFF;
				break;
			case 2:
				TXB1SIDL=((id>>13)&0xE0) | 0x8 | ((id>>16)&0x3);		// Prendemos EXIDE
				TXB1SIDH=(id>>21)&0xFF;
				TXB1EIDH=(id>>8) & 0xFF;
				TXB1EIDL=id & 0xFF;
				break;
		}
	}
}


//				BIT7	BIT6	BIT5	BIT4	BIT3	BIT2	BIT1	BIT0
//////////////////////////////////////////////////////////////////////////////////
// RXBnSIDL		SID2	SID1	SID0	-SRR-	EXIDE	----	----	----
// exide=1		EID20	EID19	EID18	----	EXIDE	----	EID17	EID16

// RXBnSIDH		SID10   SID9	SID8	SID7	SID6	SID5	SID4	SID3
// exide=1		EID28	EID27	EID26	EID25	EID24	EID23	EID22	EID21

// RXBnEIDH		EID15	EID16	EID13	EID12	EID11	EID10	EID9	EID8
// RXBnEIDL		EID7	EID6	EID5	EID4	EID3	EID2	EID1	EID0

unsigned char can_RxGetId(unsigned char buffNum, unsigned long *id)
{
	unsigned char extended=0;
	*id=0;
	switch(buffNum)
	{
		case 0:
			if (extended = (RXB0SIDL & 0x8)) {
				*id=RXB0SIDH;								// SID28-21
				*id<<=3;		*id|= (RXB0SIDL >> 5);		// SID20-18
				*id<<=2;		*id|= (RXB0SIDL & 0x3);		// SID17-16
				*id<<=8;		*id|= RXB0EIDH;				// SID15-8
				*id<<=8;		*id|= RXB0EIDL;				// SID7-0
			} else {
				*id=RXB0SIDH;				*id<<=3;
				*id=*id | RXB0SIDL>>5;
			}
			break;
		case 1: 
			if (extended = (RXB1SIDL & 0x8)) {
				*id=RXB1SIDH;								// SID28-21
				*id<<=3;		*id|= (RXB1SIDL >> 5);		// SID20-18
				*id<<=2;		*id|= (RXB1SIDL & 0x3);		// SID17-16
				*id<<=8;		*id|= RXB1EIDH;				// SID15-8
				*id<<=8;		*id|= RXB1EIDL;				// SID7-0
			} else {
				*id=RXB1SIDH;				*id<<=3;
				*id=*id | RXB0SIDL>>5;
			}
			break;
	}
	return extended>0;
}


////////////////////////////////////////////////////////
//Rx buffers. Configuraci�n m�scaras y filtros
void can_RxFilterConfig(unsigned char filterNum , unsigned long idF, unsigned char extended)		//se setea el valor de los filtros de cada buffer
{
	if (extended)
	{
		switch(filterNum) 	
		{	
			case 0:
				RXF0SIDL=(idF>>13)&0xE0 | 0x8 | (idF>>16)&0x3;		// Prendemos EXIDE
				RXF0SIDH=(idF>>21)&0xFF;
				RXF0EIDH=(idF>>8) & 0xFF;
				RXF0EIDL=idF & 0xFF;
				break;
			case 1:
				RXF1SIDL=(idF>>13)&0xE0 | 0x8 | (idF>>16)&0x3;		// Prendemos EXIDE
				RXF1SIDH=(idF>>21)&0xFF;
				RXF1EIDH=(idF>>8) & 0xFF;
				RXF1EIDL=idF & 0xFF;
				break;
			case 2:
				RXF2SIDL=(idF>>13)&0xE0 | 0x8 | (idF>>16)&0x3;		// Prendemos EXIDE
				RXF2SIDH=(idF>>21)&0xFF;
				RXF2EIDH=(idF>8) & 0xFF;
				RXF2EIDL=idF & 0xFF;
				break;
			case 3:
				RXF3SIDL=(idF>>13)&0xE0 | 0x8 | (idF>>16)&0x3;		// Prendemos EXIDE
				RXF3SIDH=(idF>>21)&0xFF;
				RXF3EIDH=(idF>8) & 0xFF;
				RXF3EIDL=idF & 0xFF;
				break;
			case 4:
				RXF4SIDL=(idF>>13)&0xE0 | 0x8 | (idF>>16)&0x3;		// Prendemos EXIDE
				RXF4SIDH=(idF>>21)&0xFF;
				RXF4EIDH=(idF>>8) & 0xFF;
				RXF4EIDL=idF & 0xFF;
				break;
		}

	} else {
		switch (filterNum)
		{
			case 0:
				RXF0SIDL=(idF & 0x7)<<5;			// extraigo los 3 bits menos significativo
				RXF0SIDH=(idF >>3 ) & 0xFF;		// extraigo los 5 bits m�s significativos
				break;
			case 1:
				RXF1SIDL=(idF & 0x7)<<5;			// extraigo los 3 bits menos significativo
				RXF1SIDH=(idF >>3 ) & 0xFF;		// extraigo los 5 bits m�s significativos
				break;
			case 2:
				RXF2SIDL=(idF & 0x7)<<5;			// extraigo los 3 bits menos significativo
				RXF2SIDH=(idF >>3 ) & 0xFF;		// extraigo los 5 bits m�s significativos
				break;
			case 3:
				RXF3SIDL=(idF & 0x7)<<5;			// extraigo los 3 bits menos significativo
				RXF3SIDH=(idF >>3 ) & 0xFF;		// extraigo los 5 bits m�s significativos
				break;
			case 4:
				RXF4SIDL=(idF & 0x7)<<5;			// extraigo los 3 bits menos significativo
				RXF4SIDH=(idF >>3 ) & 0xFF;		// extraigo los 5 bits m�s significativos
				break;
			case 5:
				RXF5SIDL=(idF & 0x7)<<5;			// extraigo los 3 bits menos significativo
				RXF5SIDH=(idF >>3 ) & 0xFF;		// extraigo los 5 bits m�s significativos
				break;
		}
	}	
}

void can_RxMaskConfig(unsigned char maskNum , unsigned int idMask)		//se determina el valor de la m�scara de cada buffer
{
	switch (maskNum)
	{
		case 0:
			RXM0SIDL=(idMask & 0x07)<<5;
			RXM0SIDH=(idMask & 0x7F8)>>3;
			break;	
		case 1:
			RXM1SIDL=(idMask & 0x07)<<5;
			RXM1SIDH=(idMask & 0x7F8)>>3;
			break;
	}
}

void can_TxSetBuffPrior(void)		//se le da una prioridad a los buffers de transmisi�n
{
	TXB0CONbits.TXPRI1=1;		TXB0CONbits.TXPRI0=1;
	TXB1CONbits.TXPRI1=1;		TXB1CONbits.TXPRI0=1;
	TXB2CONbits.TXPRI1=1;		TXB2CONbits.TXPRI0=1;
}

		
void can_TxSetDataLength(unsigned char txNumBuff , unsigned char txDataLength)		//se setea la cantidad de bytes que se transmitir�n
{
	switch (txNumBuff)
	{	
		case 2:			TXB2DLC=txDataLength;		break;
		case 1:			TXB1DLC=txDataLength;		break;
		case 0:			TXB0DLC=txDataLength;		break;	
	}
}

void can_TxSetRequestBit(unsigned char buffNum , unsigned char rtrBit)		//se determina si el mensaje es un request o no
{
	switch (buffNum)
	{
		case 0:TXB0DLCbits.TXRTR=rtrBit;
		case 1:TXB1DLCbits.TXRTR=rtrBit;
		case 2:TXB2DLCbits.TXRTR=rtrBit;
	}
}
	
unsigned char can_TxRequestStatus(unsigned char txBufferNum)		//verifica si alg�n buffer de Tx est� disponible para transmitir
{
	switch (txBufferNum)
	{
		case 0:return TXB0CONbits.TXREQ;
		case 1:return TXB1CONbits.TXREQ;
		case 2:return TXB2CONbits.TXREQ;
	}
}

void can_TxSetData(unsigned char buffNum , unsigned char byteCount, unsigned char *data)		//almacena el dato que se va a transmitir en los registros correspondientes
{
	unsigned char *p;
	int i;

	// Apuntamos al primer dato y despues nos movemos con punteros
	switch (buffNum)
	{
		case 0:	p=&TXB0D0;		break;
		case 1: p=&TXB1D0;		break;
		case 2: p=&TXB2D0;		break;
	}
	
	for(i=0; i<byteCount; i++){
		*p=*data;
		p++;
		data++;
	}
}	

//luego de haber puesto el dato en los buffers, se solicita la transmisi�n
void can_TxRequest(unsigned char buffNum)		
{
	switch(buffNum)
	{
		case 0:		TXB0CONbits.TXREQ=1;		break;
		case 1:		TXB1CONbits.TXREQ=1;		break;
		case 2:		TXB2CONbits.TXREQ=1;		break;
	}
}
	
unsigned char can_RxBuffCheck(unsigned char buffNum)		
{
	switch(buffNum)
	{
		case 0:		return RXB0CONbits.RXFUL;	
		case 1:		return RXB1CONbits.RXFUL;		
	}
}

unsigned char can_RxGetByteCount(unsigned char buffNum)
{
	switch (buffNum)
	{
		case 0:		return RXB0DLC & 0x0F;
		case 1:		return RXB1DLC & 0x0F;
	}
}

void can_RxGetData(unsigned char buffNum , unsigned char byteCount, unsigned char *data)
{
	unsigned char *p;
	int i;

	// Apuntamos al primer dato y despues nos movemos con punteros
	switch (buffNum)
	{
		case 0:	p=&RXB0D0;		break;
		case 1: p=&RXB1D0;		break;
	}
	
	for(i=0; i<byteCount; i++){
		*data=*p;
		p++;
		data++;
	}
}

unsigned char can_RxGetRtr(unsigned char buffNum)
{
	switch(buffNum)
	{
		case 0:	return RXB0DLCbits.RXRTR;
		case 1: return RXB1DLCbits.RXRTR;
	}
}

unsigned char can_RxGetFiltHitNum(unsigned char rxBuffNum)
{
	switch (rxBuffNum)
	{
		case 0:return RXB0CONbits.FILHIT0;
		case 1:return (RXB1CON & 0x7);
	}
}

void can_RxClearBuff(unsigned char buffNum)		//una vez capturado el dato, se deja libre el buffer para recivir datos nuevos
{
	switch (buffNum)
	{
		case 0:	RXB0CONbits.RXFUL=0;	break;
		case 1:	RXB1CONbits.RXFUL=0;	break;
	}
}
		
unsigned char can_RxCheckInterruptFlag(unsigned char buffNum)
{
	switch(buffNum)
	{
		case 0:		return PIR3bits.RXB0IF;		break;
	  	case 1:		return PIR3bits.RXB1IF;		break;
	}
}

void can_RxInterruptClearFlag(unsigned char buffNum)
{
	switch (buffNum)
	{
		case 0:		PIR3bits.RXB0IF=0;		break;
		case 1:		PIR3bits.RXB1IF=0;		break;
	}
}

unsigned char can_TxCheckFreeBuff(unsigned char buffNum)
{
	switch(buffNum)
	{
		case 0: 	return !TXB0CONbits.TXREQ;		break;
		case 1:		return !TXB1CONbits.TXREQ;		break;
		case 2: 	return !TXB2CONbits.TXREQ;		break;
	}
}

char can_TxFindFreeBuffer(void)
{
	if(!TXB0CONbits.TXREQ) return 0;
	if(!TXB1CONbits.TXREQ) return 1;
	if(!TXB2CONbits.TXREQ) return 2;
	return -1;
}

unsigned char can_TxCheckInterruptFlag(unsigned char buffNum)
{
	switch(buffNum)
	{
		case 0:		return PIR3bits.TXB0IF;			break;
		case 1:		return PIR3bits.TXB1IF;			break;
		case 2:		return PIR3bits.TXB2IF;			break;
	}
}

void can_TxInterruptClearFlag(unsigned char buffNum)
{
	if(buffNum==(unsigned char)0) PIR3bits.TXB0IF=0;
	if(buffNum==(unsigned char)1) PIR3bits.TXB1IF=0;
	if(buffNum==(unsigned char)2) PIR3bits.TXB2IF=0;
}

unsigned char can_ErrorSourceDetection(unsigned char errorFlag)
{
	switch(errorFlag)
	{
		//se activa porque el buffer esta lleno y hay un mensaje v�lido para entrar en dicho buffer
		case 7:		return COMSTATbits.RXB0OVFL;		break;
		//idem anterior
		case 6:		return COMSTATbits.RXB1OVFL;		break;
		//entr� en estado BUS OFF. No puede transmitir nada hasta que no se resetee
		case 5:		return COMSTATbits.TXBO;			break;
		//entr� en estado ERROR PASSIVE. Puede transmitir pero solo mensajes de error
		case 4:		return COMSTATbits.TXBP;			break;
		//idem anterior pero por causa del contador de errores de recepci�n
		case 3:		return COMSTATbits.RXBP;			break;
		//advertencia de que el contador de errores de transmisi�n super� los 95 errores
		case 2:		return COMSTATbits.TXWARN;			break;
		//advertencia de que el contador de errores de recepci�n super� los 95 errores
		case 1:		return COMSTATbits.RXWARN;			break;
		//se enciende si algunos de los dos anteriores se enciende.
		case 0:		return COMSTATbits.EWARN;			break;
	}
}

void can_ErrorReceiveOverflowClear(unsigned char buffNum)	//limpia el flag por overflow en algunos de los buffers de recepci�n
{
	switch(buffNum)
	{
		case 0:		COMSTATbits.RXB0OVFL=0;		break;
		case 1:		COMSTATbits.RXB1OVFL=0;		break;
	}
}	

////////////////////////////
//prueba
void can_CopyIcode(void)
{
	CANCONbits.WIN2=CANSTATbits.ICODE3;
	CANCONbits.WIN1=CANSTATbits.ICODE2;
	CANCONbits.WIN0=CANSTATbits.ICODE1;
}
