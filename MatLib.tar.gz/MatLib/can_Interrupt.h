#ifndef ___CANINT
#define ___CANINT
	#include "..\matlib\cirqueue_can.h"

	#define NULL 0
	
	// Si se devuelve 1 desde el callback se define que se proceso
	// el mensaje y no necesita ser encolado
	extern unsigned char (*canReceiveEvent)(far volatile canQueueData *data); 

	void canint_Isr(void);
	void canint_Init(unsigned char baudrate);
	unsigned char canint_DataAvailable(void);


	void canint_PrivateSend(unsigned char buffNum);
	void canint_PrivateReceive(unsigned char buffNum);
	void canint_Send(far volatile canQueueData *data);
	void canint_Receive(far volatile canQueueData *temp);
	void canint_TxCheck(void);
	void canint_ErrorManager(void);
	
	extern unsigned char filtHitNum;

#endif



