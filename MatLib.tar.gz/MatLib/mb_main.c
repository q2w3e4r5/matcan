#include <p18cxxx.h>
#include "mb_main.h"
#include "..\matcan\matcan.h"
#include "uart_const.h"
#include "UARTIntC.h"

#define GetByteLo(x)	(x&0x00FF)
#define GetByteHi(x)	((x&0xFF00) >> 8)

#define WRAPSHORTCOUNTER(ref,count)		((count)<(ref) ? (count)-(ref)+32678 : (count)-(ref))

unsigned short MB_idleCount;
unsigned char MB_CRCLo, MB_CRCHi;

void MB_ReadCoils(void);
void MB_ReadInputs(void);			
void MB_ReadHolding(void);
void MB_ReadInReg(void);
void MB_WriteCoils(void);
void MB_WriteRegisters(void);
char MB_ReceiveCommand(void);			

#define SM_MB_WAITCOMMAND			0
#define SM_MB_ANSWERCOMMAND			1

#define SM_MB_SENDCOMMAND			2
#define SM_MB_WAITANSWER			3
#define SM_MB_TIMEOUT				4
#define SM_MB_PROCESSANSWER			5

static unsigned char sm_mb;

////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////

//
//		SERIAL RECEIVE AND PROCESS
//

////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////

// Buffer utilizado por el puerto serie para guardar los datos recibidos
volatile unsigned char MB_waiting;					// hay un comando o respuesta en espera
volatile unsigned char MB_busy;						// Modbus esta esperando una respuesta
volatile unsigned char MB_timeout;					// Indica que hubo un timeout en la recepcion de la respuesta
unsigned char MB_timeoutCount;



unsigned char MB_cmd[MB_BUFFER_SIZE];		// Comando Modbus
unsigned char *MB_cmd_p;
unsigned char MB_cmd_count;

unsigned char MB_ans[MB_BUFFER_SIZE];		// Respuesta Modbus
unsigned char *MB_ans_p;
unsigned char MB_ans_count;



// Inicializa modbus
void MB_Init()
{
	MB_busy=0;
	MB_waiting=0;
	MB_timeout=0;

	MB_cmd_p=MB_cmd;		MB_cmd_count=0;
	MB_ans_p=MB_ans;		MB_ans_count=0;
}

// mb_Type	0 Disabled 1 Master 2 Slave
// Suponemos que nadie llama si esta disabled
void mb_Process(unsigned short plc_Clock)
{
	unsigned char d;
	
	if(UARTIntGetChar(&d)){
		MB_idleCount=plc_Clock;			// reinicializamos el counter
	
		if (mb_Type==MB_SLAVE) {		// Segun el tipo lo mandamos al buffer correspondiente
			if (MB_cmd_count<sizeof(MB_cmd))
			{
				*MB_cmd_p++=d;
				MB_cmd_count++;
			}
		} else {
			if (MB_ans_count<sizeof(MB_ans)) 
			{
				*MB_ans_p++=d;
				MB_ans_count++;
			}
		}
	}
		
	// Si no recibimos nada por mas de 3 ms, lo hacemos procesar
	if (WRAPSHORTCOUNTER(MB_idleCount, plc_Clock)>3u)  // Si han pasado 3 ms
	{
		if (mb_Type== MB_SLAVE ) {					// si es SLAVE, y tiene mas de 3 caract
			if (MB_cmd_count > 3u) {
				MB_ReceiveCommand();			

				MB_cmd_p=MB_cmd;
				MB_cmd_count=0;
			}
		} else {
			if (MB_busy) {							// si estabamos esperando respuesta
				if (MB_ans_count > 3u) {
					// Tenemos mas de 3 caracteres... debe ser una respuesta
					
					// TODO: !!!!
					
				} else {
					// Hemos tardado mucho en contestar
					MB_timeoutCount++;
					if (MB_timeoutCount>100u){
						MB_timeout=1;
						MB_busy=0;

						MB_ans_p=MB_ans;
						MB_ans_count=0;
					}
				}
			}
		}
	}
}	

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//
// Modbus Checkings
// Cheamos diferentes parametros en el paquete modbus
//


// Indica si hay una respuesta con CRC correcto
int MB_HasAnswerOK(void)
{
	if (mb_Type==MB_MASTER && MB_waiting){
		return MB_CheckCRC(MB_ans, MB_ans_p);
	} else {
		return 0;
	}
}


// Se bloquea hasta la respuesta 0 OK 1 Timeout
unsigned char MB_WaitAnswer()						
{
	if (mb_Type==MB_MASTER)
		while(!MB_waiting && !MB_timeout);
}						


//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//
// Modbus Slave Command
// Recibimos y respondemos a los diferentes comandos modbus
//
// Tres tipos de error:
// Error 0:		Falla al verificar direcci�n
// Error 1: 	Comando no reconocido
// Error 2:		Falla al verificar CRC

unsigned int start;
unsigned int count;
unsigned int value;

char MB_ReceiveCommand(void)
{
	int i;
	
	if(MB_cmd[0]!=mb_NodeId) 					return MB_SendError(0);
	if(MB_CheckCRC(MB_cmd, MB_cmd_p))			return MB_SendError(2);

	MB_ans_p=MB_ans;
	MB_ans_count=0;
	
	switch(MB_cmd[1])
	{
		case MB_READCOILSTATUS:
			MB_ans[0]=MB_cmd[0];
			MB_ans[1]=MB_cmd[1];
			start=TO_UINT(MB_cmd[2],MB_cmd[3]);
			count=TO_UINT(MB_cmd[4],MB_cmd[5]);
	
			MB_ReadCoils();						// Llena la respuesta
			MB_SendAns();
			break;
	
		case MB_READINPUTSTATUS:
			MB_ans[0]=MB_cmd[0];
			MB_ans[1]=MB_cmd[1];
			start=TO_UINT(MB_cmd[2],MB_cmd[3]);
			count=TO_UINT(MB_cmd[4],MB_cmd[5]);
	
			MB_ReadInputs();					// Llena la respuesta
			MB_SendAns();
			break;
	
		case MB_READHOLDINGREGISTER:
			if (MB_cmd_p - MB_cmd !=8) 		return MB_SendError(0);
			MB_ans[0]=MB_cmd[0];
			MB_ans[1]=MB_cmd[1];		
			start=TO_UINT(MB_cmd[2],MB_cmd[3]);
			count=TO_UINT(MB_cmd[4],MB_cmd[5]);
	
			MB_ReadHolding();
			MB_SendAns();
			break;					
			
		case MB_READINPUTREGISTERS:
			MB_ans[0]=MB_cmd[0];
			MB_ans[1]=MB_cmd[1];
			start=TO_UINT(MB_cmd[2],MB_cmd[3]);
			count=TO_UINT(MB_cmd[4],MB_cmd[5]);
	
			MB_ReadInReg();
			MB_SendAns();
			break;				
	
		case MB_FORCESINGLECOIL:		
			start=TO_UINT(MB_cmd[2],MB_cmd[3]);
	
			MB_set00000(start,MB_cmd[4]==0xFF);		
			MB_SendEchoAns();
			break;
	
		case MB_PRESETSINGLEREGISTER:
			start=TO_UINT(MB_cmd[2],MB_cmd[3]);
			value=TO_UINT(MB_cmd[4],MB_cmd[5]);
	
			MB_set40000(start,value);
			MB_SendEchoAns();
			break;
	
		case MB_READEXCEPTIONSTATUS:
			break;
	
		case MB_FORCEMULTIPLECOILS:
			start=TO_UINT(MB_cmd[2],MB_cmd[3]);
			count=TO_UINT(MB_cmd[4],MB_cmd[5]);
			
			MB_WriteCoils();
	
			MB_ans[0]=MB_cmd[0];
			MB_ans[1]=MB_cmd[1];
			MB_ans[2]=MB_cmd[2];
			MB_ans[3]=MB_cmd[3];
			MB_ans[4]=MB_cmd[4];
			MB_ans[5]=MB_cmd[5];
			MB_ans_p=MB_ans+6;
			MB_SendAns();
			break;
	
		case MB_PRESETMULTIPLEREGISTERS:
			start=TO_UINT(MB_cmd[2],MB_cmd[3]);
			count=TO_UINT(MB_cmd[4],MB_cmd[5]);
			MB_WriteRegisters();
			MB_ans[0]=MB_cmd[0];
			MB_ans[1]=MB_cmd[1];
			MB_ans[2]=MB_cmd[2];
			MB_ans[3]=MB_cmd[3];
			MB_ans[4]=MB_cmd[4];
			MB_ans[5]=MB_cmd[5];
			MB_ans_p=MB_ans+6;
			MB_SendAns();
			break;
			
	
		default:MB_SendError(1);
			break;
	}
}

void MB_SendEchoAns(void)									// Copia el comando en la respuesta
{
	unsigned char *p=MB_cmd;
	do {	UARTIntPutChar(*p++);	} while (p!=MB_cmd_p);
}

void MB_SendAns()										// Sin CRC incluido y con MB_ans_len listo
{
	unsigned char *p=MB_ans;
	
	MB_AddCRC(MB_ans, MB_ans_p);
	MB_ans_p+=2;
	
	do {	UARTIntPutChar(*p++);	} while (p!=MB_ans_p);
}

unsigned char MB_SendError(unsigned char err)				// Envia un error
{
	if(err==1u)
	{
		MB_ans[0]=MB_cmd[0];
		MB_ans[1]=MB_cmd[1]+0x80;
		MB_ans[2]=0x01;
		MB_ans_p=MB_ans+3;
		MB_SendAns();
	}

	return err;
}


//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//
// Modbus Master Commands
//
//
//
//


void MB_CommandRead(unsigned char cmd, unsigned char addr, unsigned short start, unsigned short count)
{
	if (MB_busy) return;

	MB_cmd[0]=addr;							// Seteamos el address
	MB_cmd[1]=cmd;							// Indicamos el comando
	MB_cmd[2]=GetByteHi(start);
	MB_cmd[3]=GetByteLo(start);
	MB_cmd[4]=GetByteHi(count);
    MB_cmd[5]=GetByteLo(count);
	MB_cmd_p=MB_cmd+6;

	MB_SendCmd();	
}

void MB_ForceSingleCoil(unsigned char addr, unsigned short start, unsigned char value)
{
// Recordar que value debe ser 0xFF o 0x00;
	if (MB_busy) return;
	MB_cmd[0]=addr;							// Seteamos el address
	MB_cmd[1]=MB_FORCESINGLECOIL;			// Indicamos el comando
	MB_cmd[2]=GetByteHi(start);
	MB_cmd[3]=GetByteLo(start);
	MB_cmd[4]=value;
	MB_cmd_p=MB_cmd+5;
	MB_SendCmd();	
}

void MB_PresetSingleRegister(unsigned char addr, unsigned short start, unsigned int value)
{
	if (MB_busy) return;
	MB_cmd[0]=addr;							// Seteamos el address
	MB_cmd[1]=MB_PRESETSINGLEREGISTER;		// Indicamos el comando
	MB_cmd[2]=GetByteHi(start);
	MB_cmd[3]=GetByteLo(start);
	MB_cmd[4]=GetByteHi(value);
    MB_cmd[5]=GetByteLo(value);
	MB_cmd_p=MB_cmd+6;
	MB_SendCmd();
}

// Count viene en bits
void MB_ForceMultipleCoils(unsigned char addr, unsigned short start, unsigned char count, unsigned char* data)
{
	int i;
	int nbytes;

	if (MB_busy) return;
	MB_cmd[0]=addr;							// Seteamos el address
	MB_cmd[1]=MB_FORCEMULTIPLECOILS;		// Indicamos el comando
	MB_cmd[2]=GetByteHi(start);
	MB_cmd[3]=GetByteLo(start);
	MB_cmd[4]=GetByteHi(count);
    MB_cmd[5]=GetByteLo(count);
	MB_cmd_p=MB_cmd+6;

	nbytes=(count>>3)+1;
	for(i=0; i<nbytes; i++) *MB_cmd_p++=data[i];

	MB_SendCmd();	
}

void MB_PresetMultipleRegisters(unsigned char addr, unsigned short start, unsigned char count, unsigned char *data)
{
	int i;
	int nbytes;

	if (MB_busy) return;
	MB_cmd[0]=addr;						// Seteamos el address
	MB_cmd[1]=MB_PRESETMULTIPLEREGISTERS;	// Indicamos el comando
	MB_cmd[2]=GetByteHi(start);
	MB_cmd[3]=GetByteLo(start);
	MB_cmd[4]=GetByteHi(count);
    MB_cmd[5]=GetByteLo(count);

	nbytes=count*2;
    MB_cmd[6]=nbytes;						// Numero de bytes

	MB_cmd_p=MB_cmd+7;
	for(i=0; i<nbytes; i++) *MB_cmd_p++=data[i];
	
	MB_SendCmd();

}

void MB_SendCmd(void)		// 	Aca debemos enviar el comando e iniciar el timeout por no recepcion de respuesta
{
	unsigned char *p;

	MB_AddCRC(MB_cmd,MB_cmd_p);

	MB_busy=0;
	MB_waiting=0;
	MB_timeout=0;

	p=MB_cmd;
	do {	UARTIntPutChar(*p++);	} while (p!=MB_cmd_p);

	MB_busy=1;	
	MB_timeout=0;
	MB_timeoutCount=0;
//	tmr1Enable();
}















//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////
//////////////// ACCESO AL MAPA  ///////////////////////////












////////////////////////////////////////////
// MB_ReadInputs asume
// MB_ans[0]  address   	LISTO
// MB_ans[1]  command   	LISTO

void MB_ReadInputs()
{
	unsigned int bit_start;
	unsigned int bit_p;
	unsigned int bit_count=0;
	unsigned int nbit;
	unsigned int i;

	MB_ans_p=MB_ans+3;
	bit_start=start;

	while(bit_count<count)
	{
		*MB_ans_p=0;

		bit_p=(bit_start+7>start+count ? start+count-1 : bit_start+7);
		nbit=bit_p-bit_start+1;

		for(i=0; i<nbit;i++)
		{
			*MB_ans_p<<=1;
			*MB_ans_p+=MB_get10000(bit_p)&0x1;
			bit_p--;
			bit_count++;
		}

		MB_ans_p++;
		bit_start+=8;
	}
	MB_ans[2]=MB_ans-MB_ans_p;
}

////////////////////////////////////////////
// MB_ReadCoils asume
// MB_ans[0]  address   	LISTO
// MB_ans[1]  command   	LISTO
// MB_ans[2]  start     	LISTO
// MB_ans[3]  start	   		LISTO
// MB_ans[4]  count   		LISTO
// MB_ans[5]  count   		LISTO

void MB_ReadCoils()
{
	unsigned int bit_start;
	unsigned int bit_p;
	unsigned int bit_count=0;
	unsigned int nbit;
	unsigned int i;

	MB_ans_p=MB_ans+3;
	bit_start=start;

	while(bit_count<count)
	{
		*MB_ans_p=0;

		bit_p=(bit_start+7>start+count ? start+count-1 : bit_start+7);
		nbit=bit_p-bit_start+1;

		for(i=0; i<nbit;i++)
		{
			*MB_ans_p<<=1;
			*MB_ans_p+=MB_get00000(bit_p)>0u;
			bit_p--;
			bit_count++;
		}

		MB_ans_p++;
		bit_start+=8;
	}
	
	MB_ans[2]=MB_ans_p -MB_ans -3;
}

////////////////////////////////////////////
// MB_WriteCoils asume
// MB_ans[0]  address   	LISTO
// MB_ans[1]  command   	LISTO
void MB_WriteCoils()
{	
	unsigned int bitWrite=0x1;
	unsigned char value;
	unsigned int numbits;
	unsigned int cmd_p=7;		// Tomamos los valores a partir del byte 7

	while(numbits<count)
	{
		value=(MB_cmd[cmd_p] & bitWrite)==bitWrite; //si es diferente de cero, value=1
		MB_set00000(numbits+start, value);

		bitWrite<<=1;
		if (bitWrite>=0x100u)
		{
			cmd_p++;
			bitWrite=0x1;
		}
		numbits++;
	}		
}	

////////////////////////////////////////////
// MB_ReadHolding asume
// MB_ans[0]  address   	LISTO
// MB_ans[1]  command   	LISTO
void MB_ReadHolding()
{
	unsigned int word_p;
	unsigned int value;

	MB_ans_p=MB_ans+3;
	word_p=start;

	while(word_p<count+start)
	{
		value=(int)MB_get40000(word_p++);
		*MB_ans_p++=(unsigned char)(value>>8);
		*MB_ans_p++=(unsigned char)value;
	}

	MB_ans[2]=MB_ans-MB_ans_p-3;		// Colocamos el bytecount en la respuesta
}

void MB_WriteRegisters()
{
	unsigned int i=7;
	unsigned int word_p;
	unsigned int value;
	unsigned char nbytes=MB_cmd[6]+7;

	word_p=start;

	while(i<nbytes)
	{
		value=TO_UINT(MB_cmd[i],MB_cmd[i+1]);
		i+=2;
		MB_set40000(word_p++,value);
	}	
}


////////////////////////////////////////////
// MB_ReadInReg asume
// MB_ans[0]  address   	LISTO
// MB_ans[1]  command   	LISTO
void MB_ReadInReg()
{
	unsigned int word_p;
	unsigned int value;

	MB_ans_p=MB_ans+3;
	word_p=start;

	while(word_p<count+start)
	{
		value=(int)MB_get30000(word_p++);
		*MB_ans_p++=(unsigned char)(value>>8);
		*MB_ans_p++=(unsigned char)value;
	}

	MB_ans[2]=MB_ans_p-MB_ans-3;		// Colocamos el bytecount en la respuesta
}




// Table of CRC values for high�order byte 
rom unsigned char uchTableCRCHi[] = {
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01,
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81,
0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01,
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01,
0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01,
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40
} ;

// Table of CRC values for low�order byte 
rom unsigned char uchTableCRCLo[] = {
0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4,
0x04, 0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09,
0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD,
0x1D, 0x1C, 0xDC, 0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,
0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7,
0x37, 0xF5, 0x35, 0x34, 0xF4, 0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A,
0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE,
0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,
0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2,
0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F,
0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 0x78, 0xB8, 0xB9, 0x79, 0xBB,
0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,
0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 0x50, 0x90, 0x91,
0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C,
0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 0x88,
0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80,
0x40
} ;


void CalcCRC16(unsigned char *msg, unsigned short usDataLen)
{
	unsigned uIndex; 					// will index into CRC lookup table
	unsigned short count=0;

	MB_CRCHi = 0xFF ; 	// high byte of CRC initialized 
	MB_CRCLo = 0xFF ; 	// low byte of CRC initialized 

	while (count<usDataLen) 				// pass through message buffer
	{
		uIndex = MB_CRCHi ^ msg[count] ; 	// calculate the CRC
		MB_CRCHi = MB_CRCLo ^ uchTableCRCHi[uIndex] ;
		MB_CRCLo = uchTableCRCLo[uIndex] ;
		count++;
	}
}

////////////////////////////////////
////////////////////////////////////
////////////////////////////////////
////////////////////////////////////
////////////////////////////////////
////////////////////////////////////
////////////////////////////////////
////////////////////////////////////
////////////////////////////////////
////////////////////////////////////
/////////////////  MODBUS - CRC

void MB_AddCRC(unsigned char *buffer, unsigned char *lastpos)
{
	CalcCRC16(buffer, lastpos-buffer);
	*lastpos++=MB_CRCHi;
	*lastpos++=MB_CRCLo;
}

// Chequea el CRC
int MB_CheckCRC(unsigned char *buffer, unsigned char *lastpos)
{
	CalcCRC16(buffer, lastpos-buffer-2);
	
	if (*(lastpos-2)!=MB_CRCHi) return 1;
	if (*(lastpos-1)!=MB_CRCLo) return 1;

	return 0;	// esta ok
}
