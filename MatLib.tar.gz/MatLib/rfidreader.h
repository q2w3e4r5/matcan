
void rfid_Init(void);
void rfid_Process(unsigned short plc_Clock);
