extern unsigned char CAN_BitRate;                                //Variable must be intialized here

#define	CAN_10KBPS		0
#define CAN_20KBPS		1
#define CAN_50KBPS		2
#define CAN_125KBPS		3
#define CAN_250KBPS		4
#define CAN_500KBPS		5
#define CAN_800KBPS		6
#define CAN_1000KBPS	7

#define CAN_RXANY			1		// All including errors
#define CAN_RXONLYEXTENDED	2		// Only extended
#define CAN_RXONLYSTANDARD	3		// Only standard
#define CAN_RXVALID			4		// Valid according to EXIDEN in filters

// Se definen los modos y la configuraci�n

#define can_H_ChangeModeConfig()				CANCONbits.REQOP2=1;
#define can_H_ChangeModeListen()				CANCONbits.REQOP2=0; CANCONbits.REQOP1=1; CANCONbits.REQOP0=1;
#define can_H_ChangeModeLoopback()				CANCONbits.REQOP2=0; CANCONbits.REQOP1=1; CANCONbits.REQOP0=0;
#define can_H_ChangeModeDisable()				CANCONbits.REQOP2=0; CANCONbits.REQOP1=0; CANCONbits.REQOP0=1;
#define can_H_ChangeModeNormal()				CANCONbits.REQOP2=0; CANCONbits.REQOP1=0; CANCONbits.REQOP0=0;
#define can_InConfigMode()						CANSTATbits.OPMODE2

#define can_CheckInterruptSource()   			((CANSTAT & 0b00001110) >> 1)
#define FILTERQTY	5							//el pic tiene 5 filtros de recepci�n

#define can_RxInterruptEnable()		PIE3bits.RXB0IE=1;	PIE3bits.RXB1IE=1
										//se habilitan todas las interrupciones
									/* 	b7=IRXIE interrupci�n por mensajes inv�lidos
										b6=WAKIE interrupci�n por wake up
										b5=ERRIE interrupci�n por error del bus can
										b4=TXB2IE interrupci�n por Tx2
										b3=TXB1IE interrupcion por Tx1
										b2=TXB0IE interrupcion por Tx0
										b1=RXB1IE interrupci�n por Rx1
										b0=RXB0IE interrupci�n por Rx0 
									*/

#define can_TxInterruptEnable()		PIE3bits.TXB0IE=1; 	PIE3bits.TXB1IE=1;	PIE3bits.TXB2IE=1
									/* 	b7=IRXIE interrupci�n por mensajes inv�lidos
										b6=WAKIE interrupci�n por wake up
										b5=ERRIE interrupci�n por error del bus can
										b4=TXB2IE interrupci�n por Tx2
										b3=TXB1IE interrupcion por Tx1
										b2=TXB0IE interrupcion por Tx0
										b1=RXB1IE interrupci�n por Rx1
										b0=RXB0IE interrupci�n por Rx0 
									*/

#define can_RxInterruptDisable()	PIE3bits.RXB0IE=0; PIE3bits.RXB1IE=0
									/* 	b7=IRXIE interrupci�n por mensajes inv�lidos
										b6=WAKIE interrupci�n por wake up
										b5=ERRIE interrupci�n por error del bus can
										b4=TXB2IE interrupci�n por Tx2
										b3=TXB1IE interrupcion por Tx1
										b2=TXB0IE interrupcion por Tx0
										b1=RXB1IE interrupci�n por Rx1
										b0=RXB0IE interrupci�n por Rx0 
									*/


#define can_TxInterruptDisable()	PIE3bits.TXB0IE=0; PIE3bits.TXB1IE=0; PIE3bits.TXB2IE=0	
									//se deshabilitan todas las interrupciones
									/* 	b7=IRXIE interrupci�n por mensajes inv�lidos
										b6=WAKIE interrupci�n por wake up
										b5=ERRIE interrupci�n por error del bus can
										b4=TXB2IE interrupci�n por Tx2
										b3=TXB1IE interrupcion por Tx1
										b2=TXB0IE interrupcion por Tx0
										b1=RXB1IE interrupci�n por Rx1
										b0=RXB0IE interrupci�n por Rx0 
									*/

#define can_ErrorInterruptClearFlag()	PIR3bits.ERRIF=0;	//limpia el flag por interrupci�n de errores
#define can_ErrorInterruptDisable()		PIE3bits.ERRIE=0;	//deshabilita la interrupci�n por errores

extern unsigned char filterBusy;

///////////////////////////////////////////
//  INICIALIZACION

void can_DrvInit(void);
void can_CheckConfigMode(void);
void can_SetBaudRate(unsigned char CAN_BitRate);
void can_RxMessageType(unsigned char type);

unsigned char can_RxGetId(unsigned char buffNum, unsigned long *id);
void can_TxSetId(unsigned char buffNum , unsigned long id, unsigned char extended);


char can_RxFilterAvailable(void);
void can_TxSetBuffPrior(void);
void can_TxSetDataLength(unsigned char , unsigned char);
void can_TxSetRequestBit(unsigned char buffNum , unsigned char rtrBit);
unsigned char can_TxRequestStatus(unsigned char);
void can_TxSetData(unsigned char  , unsigned char , unsigned char *);
unsigned char can_RxBuffCheck(unsigned char buffNum);
unsigned char can_RxGetByteCount(unsigned char);
void can_RxGetData(unsigned char buffNum , unsigned char byteCount, unsigned char *data);

unsigned char can_RxGetRtr(unsigned char );
void can_RxClearBuff(unsigned char buffNum);

void can_RxFilterConfig(unsigned char filterNum , unsigned long idF, unsigned char extended);
void can_RxMaskConfig(unsigned char maskNum , unsigned int idMask);


unsigned char can_RxGetFiltHitNum(unsigned char rxBuffNum);
unsigned char can_RxCheckInterruptFlag(unsigned char buffNum);

void can_RxInterruptClearFlag(unsigned char buffNum);
unsigned char can_TxCheckFreeBuff(unsigned char buffNum);
void can_TxRequest(unsigned char buffNum);
unsigned char can_TxCheckInterruptFlag(unsigned char buffNum);
char can_TxFindFreeBuffer(void);
void can_TxInterruptClearFlag(unsigned char bufferFlag);
/////////////////////////////////////////////

////////////////////////////////errores de interrupcion
unsigned char can_ErrorSourceDetection(unsigned char errorFlag);
void can_ErrorReceiveOverflowClear(unsigned char buffNum);



/////////////////////////////
//PRUEBA
void can_CopyIcode(void);
