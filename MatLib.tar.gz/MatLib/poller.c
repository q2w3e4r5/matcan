#include "poller.h"
#include "mb_main.h"
/// CONSULTA DIFERENTES CONTROLADORES BASADOS EN MODBUS

unsigned char poll_mappingCount;
unsigned char poll_p;
unsigned char poll_mode;	
pollMapping_t pollMapping[POLLSIZE];	// Configuracion del pollMapping

void poll_Init(void)
{
	poll_p=0;
	poll_mode=MODE_READ;
	poll_mappingCount=0;
}

void poll_Add(unsigned char addr, unsigned char count, unsigned int start, unsigned char *location, unsigned char max_size, unsigned char mode)
{
	pollMapping[poll_mappingCount].addr=addr;		
	pollMapping[poll_mappingCount].count=count;		
	pollMapping[poll_mappingCount].start=start;		
	pollMapping[poll_mappingCount].location=location;		
	pollMapping[poll_mappingCount].max_size=max_size;		
	pollMapping[poll_mappingCount].mode=mode;
	poll_mappingCount++;
}

void poll_Next(void)
{
	poll_p++;
	if (!(poll_p<poll_mappingCount)) poll_p=0;

}

unsigned char copySize;
unsigned char i;
far unsigned char *p,*q;

void poll_Process(void)
{
	if (!MB_busy){					// Si no esta busy podemos pedir algo

		if (MB_timeout){
			MB_timeout=0;			// Vemos si tuvimos un error
			poll_Next();
		}

		if (!mb_Type==MB_MASTER && MB_waiting){							// Vemos si tenemos una respuesta pendiente
			if (!MB_HasAnswerOK()){				
				if (poll_mode==MODE_READ)	{
					copySize=pollMapping[poll_p].max_size;
					if (MB_ans[2]<copySize) copySize=MB_ans[2];
				
					p=pollMapping[poll_p].location;
					q=MB_ans+3;
					for(i=0; i<copySize; i++,p++, q++) *p=*q;
			
//					mappingBuffer=mappingMemory+pollMapping[poll_p].location;			// Copiamos la respuesta en el mapping buffer
//					memcpy((void *)mappingBuffer, (void *)(mb_ans+3), mb_ans[2]);
				}
//					mb_PresetSingleRegister(11, 1002, tempPixSYS);
//					mb_WaitAnswer();
			};
			poll_Next();
		}
		
		if (pollMapping[poll_p].mode & POLLREAD)
		{
			MB_ReadHoldingRegister(	pollMapping[poll_p].addr,			// Mandamos un comando para leer segun poll mapping
								    pollMapping[poll_p].start,
									pollMapping[poll_p].count);					
	//				Delay10KTCYx(146);		// 1  ms aprox						// Aca deberiamos procesar la respuesta
		} else {
//				mappingBuffer=mappingMemory+pollMapping[poll_p].location;
//				mb_PresetMultipleRegisters(	pollMapping[poll_p].addr,			// Mandamos un comando para leer segun poll mapping
//									    	pollMapping[poll_p].start,
//											pollMapping[poll_p].count,
//											(unsigned char *)(mappingBuffer)
//											);
		} 
	}	
}
