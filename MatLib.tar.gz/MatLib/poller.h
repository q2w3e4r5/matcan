// Consulta dispositivos Modbus
#define POLLSIZE					20
#define POLLREAD					0b00000001
#define POLLWRITE					0b00000010

typedef struct {
	unsigned char addr;			//	Address to poll
	unsigned char count;		//	Count
	unsigned int  start;		//	Starting Register
	unsigned char  *location;		//  Memory location to copy information	
	unsigned char max_size;		//  Maximum buffer size
	unsigned char mode;			//	Should resend same info
} pollMapping_t;

#define		MODE_READ	0u
#define		MODE_WRITE	1u


void poll_Process(void);
void poll_Init(void);
void poll_Add(unsigned char addr, unsigned char count, unsigned int start, unsigned char *location, unsigned char max_size, unsigned char mode);
