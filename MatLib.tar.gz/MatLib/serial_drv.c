#include<p18f2680.h>
#include "serial_drv.h"

#if OSCFREQ == 20
	#if SERIAL_BAUDRATE == 2400
		#define USART_SPBRG   520
	#endif
	#if SERIAL_BAUDRATE == 9600
		#define USART_SPBRG   129
	#endif
	#if SERIAL_BAUDRATE == 19200
		#define USART_SPBRG   64
	#endif
	#if SERIAL_BAUDRATE == 38400
		#define USART_SPBRG   32
	#endif
	#if SERIAL_BAUDRATE == 57600
		#define USART_SPBRG   21
	#endif
	#if SERIAL_BAUDRATE == 115200
		#define USART_SPBRG   10
	#endif
#endif
#ifndef USART_SPBRG
	#error define_USART_SPBRG_Not_Supported
#endif

void serial_Init(void)
{
	OpenUSART(USART_FLAGS,USART_SPBRG);

/////////////////////////////
//Configuraci�n de las interrupciones de serial bus

	IPR1bits.TXIP=0;			//SE SETEAN LAS PRIORIDADES PARA LA TX 1 Alta 0 Baja
	IPR1bits.RCIP=0;			//SE SETEAN LAS PRIORIDADES PARA LA RX 1 Alta 0 Baja

	PIE1bits.TXIE=0;			//SE HABILITAN LAS INTERRUPCIONES POR TX
	PIE1bits.RCIE=1;			//SE HABILITAN LAS INTERRUPCIONES POR RX

	TRISCbits.TRISC7=1;
	TRISCbits.TRISC6=0;

	#ifdef rs485
		serial_EnableRs485Reception();
	#endif
}

void serial_Send(unsigned char serialdata)
{
	putcUSART(serialdata);
}

void serial_Receive(far volatile unsigned char* serialdata)
{
	*serialdata=ReadUSART();	
}

void serial_checkUsartReceptionStatus(void)
{
	if(RCSTAbits.OERR)
	{
		RCSTAbits.CREN=0;		//Si hay algun error en la recepci�n, se limpia el flag cambiando de estado el bit CREN
		RCSTAbits.CREN=1;
	}
}
