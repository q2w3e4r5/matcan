#include <p18f2680.h>
#include<stdio.h>
#include "serial_drv.h"
#include "serial_Interrupt.h"

unsigned char (*serialReceiveEvent)(unsigned char serialdata) = NULL;   

unsigned char txFront;
unsigned char txRear;
unsigned char txCount;
unsigned char rxFront;
unsigned char rxRear;
unsigned char rxCount;

unsigned char txBuffer[100];
unsigned char rxBuffer[100];

void serialint_Init(void)
{
	// Inicializamos el TXbuffer
	txFront=0;
	txRear=0;
	txCount=0;
	
	rxFront=0;
	rxRear=0;
	rxCount=0;
	
	serial_Init();	
}

unsigned char serialint_Isr(void)
{
	if (!serial_IsrEnabled()) return 0;

	if (serial_RxSource()){
		serialint_PrivateReceive();
		serial_RxClearFlag();
		serial_checkUsartReceptionStatus();				//verifica que la USART est� ok
		return 1;
	}
	
	if (serial_TxSource()){
		serialint_PrivateSend();
	//			serial_TxClearFlagInterrupt();
		return 2;
	}

	return 0;
}


void serialint_PrivateSend(void)
{
	unsigned char serialdata;

	if (!serial_TxFlag()) return;		// Si la bandera de TX no esta en 1, salimos rapidamente

	if(txCount==0u)
	{	
		serial_TxDisableInterrupt();		//si no hay nada en la cola, desactiva la interrupci�n por serialtx		
		#ifdef rs485
			serial_EnableRs485Reception();
		#endif
	}
	else 
	{
		#ifdef rs485
			serial_EnableRs485Transmition();
		#endif

		serialdata=txBuffer[txRear];
		txRear=(txRear>sizeof(txBuffer) ? 0 : txRear+1);
		txCount--;	
		
		serial_Send(serialdata);								//capturo el dato
	}
}


void serialint_Send(unsigned char serialdata)		///ATENCION!!!!!ARREGLAR QUE CUANDO SE ENV�AN S�LO DOS BYTES SE QUEDA TRABADO EL MODO DE TRANSMISI�N EN RS485.
{
	serial_TxDisableInterrupt();		// Desactivo las interrupciones de salida para protejer la cola

	if (txCount<sizeof(txBuffer)) {
		txBuffer[txFront]=serialdata;
		txFront=(txFront>sizeof(txBuffer) ? 0 : txFront+1);
		txCount++;
	}
	
	if (txCount>0u) serial_TxEnableInterrupt();
}


unsigned char serialint_txQueueCount(void)
{
	// Si no esta vacia activamos las interrupciones de salida para que siga mandando..
	unsigned char tmp;	
	serial_TxDisableInterrupt();
	tmp=txCount;
	if (tmp>0u) serial_TxEnableInterrupt();
	return tmp;
}

///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////

void serialint_RxClear(void)
{
	serial_RxDisableInterrupt();
	rxFront=0;
	rxRear=0;
	rxCount=0;
	serial_RxEnableInterrupt();
}

void serialint_TxClear(void)
{
	serial_TxDisableInterrupt();
	txFront=0;
	txRear=0;
	txCount=0;
	serial_TxEnableInterrupt();
}

void serialint_Receive(unsigned char *serialdata)
{
	serial_RxDisableInterrupt();

	*serialdata=rxBuffer[rxRear];
	rxRear=(rxRear>sizeof(rxBuffer) ? 0 : rxRear+1);
	rxCount--;

	serial_RxEnableInterrupt();
}

unsigned char serialint_DataAvailable(void)				//verifica si hay datos en la cola de recepci�n
{
	unsigned char count;		

	serial_RxDisableInterrupt();
	count=rxCount;										//Se ve si hay datos en la cola
	serial_RxEnableInterrupt();

	return count;										//se devuelve el dato para que se transmita en rs232
}

void serialint_PrivateReceive(void)
{
	volatile unsigned char serialdata;

	serial_Receive((volatile unsigned char*)&serialdata);					//capturo el dato
	if (serialReceiveEvent!=NULL) 
		if ( (*serialReceiveEvent)(serialdata) != 0u)
			return; 

	if (rxCount<sizeof(rxBuffer)){	
		rxBuffer[rxFront]=serialdata;
		rxFront=(rxFront>sizeof(rxBuffer)?0:rxFront+1);
		rxCount++;
	}
}

////////////////////////////////////////////////////////////

void serialint_TxCopyBuffer(unsigned char *src, unsigned char len)
{
	unsigned char *serialdata;		
	unsigned char i=0;

	serial_TxDisableInterrupt();		// Desactivo para proteger la cola
	serialdata=src;

	for(i=0; i<len; i++)
	{
		if (txCount<sizeof(txBuffer)) {
			txBuffer[txFront]=*serialdata;
			txFront=(txFront>sizeof(txBuffer) ? 0 : txFront+1);
			txCount++;
		}

		serialdata++;
	}

	serial_TxEnableInterrupt();			// Activo para comenzar a enviar
}

void serialint_RxCopyBuffer(unsigned char *dest, unsigned char *len)
{
	unsigned char *serialdata;		

	serial_RxDisableInterrupt();

	serialdata=dest;
	*len=rxCount;

	while( rxCount > 0u)					//Se ve si hay datos en la cola
	{
		*serialdata=rxBuffer[rxRear];
		rxRear=(rxRear>sizeof(rxBuffer) ? 0 : rxRear+1);
		rxCount--;
		serialdata++;
	}

	serial_RxEnableInterrupt();
}

void serialint_RxCopyBufferDelim(unsigned char *dest, unsigned char *len, unsigned char delim)
{
	unsigned char *serialdata;		

	serial_RxDisableInterrupt();

	serialdata=dest;
	*len=rxCount;

	while( rxCount > 0u)					//Se ve si hay datos en la cola
	{
		*serialdata=rxBuffer[rxRear];
		rxRear=(rxRear>sizeof(rxBuffer) ? 0 : rxRear+1);
		rxCount--;
		
		if (*serialdata==delim) break;		// Si encontramos un delimiter no seguimos
		serialdata++;
	}

	serial_RxEnableInterrupt();
}
