int ee_ReadByte(char addr);							// Lee un byte de la EEPROM
int ee_ReadWord(char addr);							// Lee un word de la EEPROM

void ee_WriteWord(int addr,unsigned int data);		// Escribe un word en EEPROM
void ee_WriteByte(int addr, char data);				// Escribe un byte en EEPROM
