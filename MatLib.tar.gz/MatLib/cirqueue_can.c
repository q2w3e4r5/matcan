#include "cirqueue_can.h"

#define cq_wrapAroundAdd(x,sz) ( ((x<(sz-1)) ? x+1 : 0) )
#define cq_wrapAroundSub(x,sz) ( (x>0 ? x-1 : sz-1) )
#define cq_swapData(a, b, c)   c=a; a=b; b=c;

void cq_canInit(far volatile canQueue *q)
{
	q->count=0;
	q->front=0;
	q->rear=0;
}

int cq_canCount(far volatile canQueue *q)
{
	return q->count;
}

int cq_canIsFull(far volatile canQueue *q)
{
	return q->count>=QUEUESIZEcan;
}

 void cq_canQueue(far volatile canQueue *q, far volatile canQueueData *data)
{
#ifdef cq_Sort
#ifdef cq_Prio
	int i,j;
	int bubblingUp;
#endif
#endif
		
	if (q->count<QUEUESIZEcan) {
		q->data[q->rear]=*data;
		q->count++;
		q->rear=cq_wrapAroundAdd(q->rear, QUEUESIZEcan);
	}

#ifdef cq_Sort
#ifdef cq_Prio
// Reordenamos en base a la prioridad
// Estamos en rear y tenemos que movernos hasta front
	if (q->count>1){
		bubblingUp=1;
		i=q->rear;
		do {
			bubblingUp=0;
			i=cq_wrapAroundSub(i, QUEUESIZEcan);
			j=cq_wrapAroundSub(i, QUEUESIZEcan);

			if ( cq_Sort ( cq_Prio(q,i),cq_Prio(q,j)) ) {
				cq_swapData(q->data[i], q->data[j], *data);
				if (j!=q->front) bubblingUp=1;
			}
		} while(bubblingUp);
	}
#endif
#endif
	
}

void cq_canDeque(far volatile canQueue *q, far volatile canQueueData *data)
{
	if (q->count>0u){
		*data=q->data[q->front];
		q->count--;
		q->front=cq_wrapAroundAdd(q->front, QUEUESIZEcan);
	}
}
