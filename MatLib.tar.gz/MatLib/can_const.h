/*******************************************************************************
   CAN bit rates - Registers setup
*******************************************************************************/
rom struct{
   unsigned char BRP;         //(1...64)Baud Rate Prescaler
   unsigned char SJW;         //(1...4) SJW time
   unsigned char PROP;        //(1...8) PROP time
   unsigned char PhSeg1;      //(1...8) Phase Segment 1 time
   unsigned char PhSeg2;      //(1...8) Phase Segment 2 time
} CAN_BitRateData[8] =

#if MAT_OSC_FREQ == 4
  {{10,  1, 8, 8, 3}, //CAN=10kbps
   {5,   1, 8, 8, 3}, //CAN=20kbps
   {2,   1, 8, 8, 3}, //CAN=50kbps
   {1,   1, 5, 8, 2}, //CAN=125kbps
   {1,   1, 2, 4, 1}, //CAN=250kbps
   {1,   1, 1, 1, 1}, //CAN=500kbps
   {1,   1, 1, 1, 1}, //CAN=800kbps     //Not possible
   {1,   1, 1, 1, 1}};//CAN=1000kbps    //Not possible
#elif MAT_OSC_FREQ == 8
  {{25,  1, 5, 8, 2}, //CAN=10kbps
   {10,  1, 8, 8, 3}, //CAN=20kbps
   {5,   1, 5, 8, 2}, //CAN=50kbps
   {2,   1, 5, 8, 2}, //CAN=125kbps
   {1,   1, 5, 8, 2}, //CAN=250kbps
   {1,   1, 2, 4, 1}, //CAN=500kbps
   {1,   1, 1, 2, 1}, //CAN=800kbps
   {1,   1, 1, 1, 1}};//CAN=1000kbps
#elif MAT_OSC_FREQ == 16
  {{50,  1, 5, 8, 2}, //CAN=10kbps
   {25,  1, 5, 8, 2}, //CAN=20kbps
   {10,  1, 5, 8, 2}, //CAN=50kbps
   {4,   1, 5, 8, 2}, //CAN=125kbps
   {2,   1, 5, 8, 2}, //CAN=250kbps
   {1,   1, 5, 8, 2}, //CAN=500kbps
   {1,   1, 3, 4, 2}, //CAN=800kbps
   {1,   1, 2, 3, 2}};//CAN=1000kbps
#elif MAT_OSC_FREQ == 20
  {{50,  1, 8, 8, 3}, //CAN=10kbps
   {25,  1, 8, 8, 3}, //CAN=20kbps
   {10,  1, 8, 8, 3}, //CAN=50kbps
   {5,   1, 5, 8, 2}, //CAN=125kbps
   {2,   1, 8, 8, 3}, //CAN=250kbps
   {1,   1, 8, 8, 3}, //CAN=500kbps
   {1,   1, 8, 8, 3}, //CAN=800kbps     //Not possible
   {1,   1, 3, 4, 2}};//CAN=1000kbps
#elif MAT_OSC_FREQ == 24
  {{63,  1, 8, 8, 2}, //CAN=10kbps
   {40,  1, 4, 8, 2}, //CAN=20kbps
   {15,  1, 5, 8, 2}, //CAN=50kbps
   {6,   1, 5, 8, 2}, //CAN=125kbps
   {3,   1, 5, 8, 2}, //CAN=250kbps
   {2,   1, 3, 6, 2}, //CAN=500kbps
   {1,   1, 5, 7, 2}, //CAN=800kbps
   {1,   1, 3, 6, 2}};//CAN=1000kbps
#elif MAT_OSC_FREQ == 32
  {{64,  1, 8, 8, 8}, //CAN=10kbps
   {50,  1, 5, 8, 2}, //CAN=20kbps
   {20,  1, 5, 8, 2}, //CAN=50kbps
   {8,   1, 5, 8, 2}, //CAN=125kbps
   {4,   1, 5, 8, 2}, //CAN=250kbps
   {2,   1, 5, 8, 2}, //CAN=500kbps
   {2,   1, 3, 4, 2}, //CAN=800kbps
   {2,   1, 2, 3, 2}};//CAN=1000kbps
#elif MAT_OSC_FREQ == 40
  {{50,  1, 8, 8, 3}, //CAN=10kbps      //Not possible
   {50,  1, 8, 8, 3}, //CAN=20kbps
   {25,  1, 5, 8, 2}, //CAN=50kbps
   {10,  1, 5, 8, 2}, //CAN=125kbps
   {5,   1, 5, 8, 2}, //CAN=250kbps
   {2,   1, 8, 8, 3}, //CAN=500kbps
   {1,   1, 8, 8, 8}, //CAN=800kbps
   {2,   1, 2, 5, 2}};//CAN=1000kbps
#else
   #error define_CO_OSCILATOR_FREQ MAT_OSC_FREQ not supported
#endif


#define BRGCON1_VAL ((CAN_BitRateData[CAN_BitRate].SJW-1) <<6 ) | (CAN_BitRateData[CAN_BitRate].BRP-1)
#define BRGCON2_VAL	(0x80 | ((CAN_BitRateData[CAN_BitRate].PhSeg1-1)<<3) | (CAN_BitRateData[CAN_BitRate].PROP-1))
#define BRGCON3_VAL	(CAN_BitRateData[CAN_BitRate].PhSeg2-1)
