#ifndef ___CIRQUEUEcan
#define ___CIRQUEUEcan
	#define QUEUESIZEcan 8u					// Definir el tama�o de la cola

	 struct can_Data
	{
		union _ID {
			unsigned long dword;
			struct {
				unsigned char lo;
				unsigned char hi;
				unsigned char elo;
				unsigned char ehi;
			} byte;
		} id;
		
		unsigned char rtr:1;
		unsigned char extended:1;
		unsigned char byteCount:4;
		
		unsigned char data[8];
	};

	typedef struct can_Data canQueueData;		// Definir el tipo de dato que se mete en la cola

	typedef struct canqueue {
		unsigned char count;
		unsigned char front;
		unsigned char rear;
		canQueueData data[QUEUESIZEcan];
	};

	typedef struct canqueue canQueue;
	
	void cq_canInit(far volatile canQueue *q);
	int cq_canCount(far volatile canQueue *q);
	int cq_canIsFull(far volatile canQueue *q);
	
	void cq_canDeque(far volatile canQueue *q, far volatile canQueueData *data);
	void cq_canQueue(far volatile canQueue *q, far volatile canQueueData *data);

//	#define cq_Sort(a,b)	(a<b)			// El orden a utilizar, si se define se utiliza
//	#define cq_Prio(q,i)	q->data[i].stId.Id		// Devolver el valor de la prioridad elemento i

#endif
