
Para cambiar la direccion del nodo


--- CO_OD.h ---

   #define ODD_CANnodeID    0x01 //(1 to 127), default node ID

