#include "can_drv.h"
#include "can_Interrupt.h"
#include <p18cxxx.h>

unsigned char filtHitNum=0;
unsigned char lockInterrupt=0;

unsigned char (*canReceiveEvent)(far volatile canQueueData *data) = NULL;

volatile canQueue canint_RxQueue, canint_TxQueue;

void canint_Init(unsigned char baudrate)						
{
	cq_canInit(&canint_RxQueue);
	cq_canInit(&canint_TxQueue);
	can_SetBaudRate(baudrate);
	can_DrvInit();
}

void canint_Isr(void)						//rutina de interrupci�n de can
{
	if (!can_CheckInterruptSource()) return;

	if (can_CheckInterruptSource()==6){		
		canint_PrivateReceive(0);	
		can_RxInterruptClearFlag(0);	
	}
	
	if (can_CheckInterruptSource()==5){		
		canint_PrivateReceive(1);	
		can_RxInterruptClearFlag(1);	
	}
	
	if (can_CheckInterruptSource()==4){		canint_PrivateSend(0);		can_TxInterruptClearFlag(0);	}
	if (can_CheckInterruptSource()==3){		canint_PrivateSend(1);		can_TxInterruptClearFlag(1);	}
	if (can_CheckInterruptSource()==2){		canint_PrivateSend(2);		can_TxInterruptClearFlag(2);	}
	if (can_CheckInterruptSource()==1){		canint_ErrorManager();		can_ErrorInterruptClearFlag();	}
}

void canint_Send(far volatile canQueueData *temp)
{	
	char buffNum;
	can_TxInterruptDisable();						// desde este momento no se puede interrumpir m�s

	buffNum=can_TxFindFreeBuffer();

	if((cq_canCount(&canint_TxQueue)==0) && (buffNum>=0))//si la cola est� vac�a y hay algun buffer libre, lo manda sin encolar
	{
		can_TxSetId(buffNum , temp->id.dword, temp->extended);	//setea id
		can_TxSetDataLength(buffNum , temp->byteCount);
		can_TxSetBuffPrior();									//setea la prioridad del buffer de tx
		can_TxSetRequestBit(buffNum , temp->rtr);				//setea el RTR
		can_TxSetData(buffNum,  temp->byteCount, &(temp->data[0]));	//coloca el dato para ser transmitido
		can_TxRequest(buffNum);
	}
	else
	{
		cq_canQueue(&canint_TxQueue, temp);	// sino, se pone el dato de la cola
	}	
	can_TxInterruptEnable();						// se habilitan las interrupciones	
}

// Tenemos un buffer libre
// Si hay algo en la cola lo colocamos en ese buffer
void canint_PrivateSend(unsigned char buffNum)											//rutina de transmisi�n
{
	volatile struct can_Data temp;
	if(cq_canCount(&canint_TxQueue)>0u )
	{
		cq_canDeque(&canint_TxQueue,(volatile far canQueueData *)&temp);								//se saca el dato de la cola y se guarda en temp
		can_TxSetId(buffNum , temp.id.dword, temp.extended);	//setea id
		can_TxSetDataLength(buffNum , temp.byteCount);
		can_TxSetBuffPrior();									//setea la prioridad del buffer de tx
		can_TxSetRequestBit(buffNum , temp.rtr);				//setea el RTR
		can_TxSetData(buffNum,  temp.byteCount, &(temp.data[0]));	//coloca el dato para ser transmitido
		can_TxRequest(buffNum);									//da la orden de transmisi�n
	} 
}

void canint_PrivateReceive(unsigned char buffNum)				//se ha recibido algo, hay que recuperar y almacenar los datos de la recepci�n.
{
	int cancelQueue=0;
	volatile struct can_Data temp;

	temp.byteCount=can_RxGetByteCount(buffNum);					//se recupera el byte count				
	can_RxGetData( buffNum , temp.byteCount, &(temp.data[0]));	//se recupera el campo del data
	temp.extended=can_RxGetId(buffNum, &temp.id.dword);			//se recupera el id
	temp.rtr=can_RxGetRtr(buffNum);								//se captura el bit RTR
	filtHitNum=can_RxGetFiltHitNum(buffNum);					//se captura el n�mero del filtro que permiti� la recepci�n

// Ya tenemos el paquete en temp
	if (canReceiveEvent!=NULL) {
		cancelQueue=(*canReceiveEvent)((far volatile canQueueData *)&temp);
	}							

/////////////

	if (cancelQueue==0){
		cq_canQueue(&canint_RxQueue, &temp);		//se pasa toda el struct a la cola
	
	}
	can_RxClearBuff(buffNum);		//se limpia el indicador de dato recibido, permitiendo ahora la recepci�n de un dato nuevo
}		


void canint_Receive(far volatile canQueueData *temp)
{
	can_RxInterruptDisable();						//se deshabilitan las interrupciones por recepci�n para no romper la cola
	cq_canDeque(&canint_RxQueue, temp);				//se saca el dato de la cola
	can_RxInterruptEnable();						//si canint_RxInterrupt es cero, entonces hay que habilitar las interrupciones
}

unsigned char canint_DataAvailable(void)				//verifica si hay datos en la cola de recepci�n
{
	unsigned char data;		
	can_RxInterruptDisable();						//se deshabilitan las interrupciones por recepci�n para no romper la cola
	data=cq_canCount(&canint_RxQueue);				//Se ve si hay datos en la cola
	can_RxInterruptEnable();						//si canint_RxInterrupt es cero, entonces hay que habilitar las interrupciones
	return data;									//se devuelve el dato para que se transmita en rs232
}

void canint_ErrorManager(void)
{
	if(can_ErrorSourceDetection(7)) 
	{	
		if(can_RxBuffCheck(0))	canint_PrivateReceive(0);	//verifica si fue por overflow de Rxb0
		can_ErrorReceiveOverflowClear(0);				//limpia el flag
		return;
	}	
	if(can_ErrorSourceDetection(6))
	{
		if(can_RxBuffCheck(1))canint_PrivateReceive(1);	//verifica si fue por overflow de Rxb1
		can_ErrorReceiveOverflowClear(1);
		return;
	}
	if(can_ErrorSourceDetection(5)) //verifica si est� en Bus Off y resetea el micro 
	{
		Reset();
		return;
	}
/*	if(can_ErrorSourceDetection(4)) //verifica si entr� en error passive debido a transmisi�n
	{
		can_ErrorInterruptDisable();
		
	}
	if(can_ErrorSourceDetection(3))	//verifica si entr� en error passive debido a la recepci�n
	{
		can_ErrorInterruptDisable();
	}
		
	if(can_ErrorSourceDetection(2))	//verifica si hay alarma por transmisi�n
	{
		can_ErrorInterruptDisable();
	}
	
	if(can_ErrorSourceDetection(1))	//verifica si hay alarma por recepci�n
	{
		can_ErrorInterruptDisable();
	}
	if(can_ErrorSourceDetection(0))	//verifica si hay alarma por transmimisi�n o recepci�n
	{
		can_ErrorInterruptDisable();
	}
*/
}
