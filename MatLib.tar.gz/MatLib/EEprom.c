#include<p18f2620.h>
#include "EEprom.h"

///////////////////////////////////////////////////
////DATOS ALMACENADOS EN EEPROM
////
void ee_WriteByte(int addr, char data)
{
		 
	EEADRH=0;
	EEADR = addr; 
	EEDATA = data; 
	EECON1bits.EEPGD = 0; 
	EECON1bits.CFGS = 0; 
	EECON1bits.WREN = 1;
	INTCONbits.GIEH=0;	//desactiva las interrupciones 
	EECON2 = 0x55; 
	EECON2 = 0xaa; 
	EECON1bits.WR = 1; 
	while (!PIR2bits.EEIF);
	PIR2bits.EEIF = 0; 
			
	INTCONbits.GIEH=1; 
}

void ee_WriteWord(int addr,unsigned int data)
{
	ee_WriteByte(addr, data>>8);
	ee_WriteByte(addr+1, data&0xFF);
}
		
int ee_ReadByte(char addr)
{
	EEADRH=0;
	EEADR = addr; 
	EECON1bits.EEPGD = 0;
	EECON1bits.CFGS=0;
	EECON1bits.RD = 1; 
	return EEDATA; 
}

int ee_ReadWord(char addr)
{
	int evalue;
	ee_ReadByte(addr);
	evalue=EEDATA;
	evalue<<=8;
	ee_ReadByte(addr+1);
	evalue+=EEDATA;
	return evalue;	
	 
}	
