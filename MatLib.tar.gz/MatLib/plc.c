#include "plc.h"

#define STACK_SIZE					100u
#define ALM_MAX_ZONE_NUMBER			10u

#define ALM_FIRST_INDEX				0u
#define ALM_NR_INDICES				10u

#define DELAY_FIRST_INDEX			10u
#define DELAY_NR_INDICES			32u


// Stack macros

#define STACK_GETBYTE()				(sp>0u? stack[--sp]: 0u)
#define STACK_PEEKBYTE()			(sp>0u? stack[sp-1]: 0u)
#define STACK_GETWORD(x) 			{ x=STACK_GETBYTE(); x<<=8; 	x+=STACK_GETBYTE(); }
#define STACK_PEEKWORD(x)  			{ x=(sp>0u? stack[sp-1]: 0u); x<<=8;  x+=(sp>0u? stack[sp-2]: 0u); }

#define STACK_PUTBYTE(x)			(sp<STACK_SIZE? stack[sp++]=x: 0)
#define STACK_PUTWORD(x) 			{ STACK_PUTBYTE( x & 0xFF );  STACK_PUTBYTE( x >> 8   ); }

// Memory macros

#define getBit(mem,p,v)  			v=((*(mem+(p>>3))) & (1<<(p&0x7)))			// Tomamos el bit
#define getByte(mem,p,v)			v=(*(mem+p))								// Tomamos el byte
#define getWord(mem,p,v)			{ v=(*(mem+p)); v<<=8; v+=(*(mem+p+1)); }	// Tomamos el word
#define setBit(mem,p,v)				if (v==0) (*(mem+(p>>3)))&=(0xFF-(1<<(p&0x7))); else (*(mem+(p>>3)))|=(1<<(p&0x7))

#define setByte(mem,p,v)			(*(mem+p)=v)
#define setWord(mem,p,v)			setByte(mem,p,(v&0xFF)); setByte(mem,p+1, (v>>8))

// Internal variables

//unsigned char 		pc;								// Program counter
unsigned char 		sp;								// Stack pointer
unsigned char 		stack[STACK_SIZE];
short					op2;							// Operand 2
short					op3;							// Operand 2
short 				plc_Wdata;						// PLC working data

//unsigned short 	plc_dimmerCounterStart[32];		//	


//////////////////////////////////////////////////////
//
//	Variables de la alarma
//
#pragma udata ALARM_PLC
short			alm_mainZoneDelayClock[ALM_NR_INDICES];					// Clock MainZone Delay
short			alm_desactivateDelayClock[ALM_NR_INDICES];				// Clock Alarm Desactivation
short			alm_sireneDelayClock[ALM_NR_INDICES];					// Clock desactivacion sirena
short			alm_mzHit[ALM_NR_INDICES];								// Main Zone hit
unsigned char 	old_alm_active[ALM_NR_INDICES];							// Old Alarm Active
short 			alm_sireneOn[ALM_NR_INDICES];							// Sirene On
short			mainZoneDelayFlag[ALM_NR_INDICES];						// Main Zone delay flag
short			mainZoneAlarm[ALM_NR_INDICES];							// Main Zone alarm
#pragma udata

//////////////////////////////////////////////////////
//
//	Variables del delay
//
#pragma udata DELAY_PLC1
unsigned char 	old_delay_Entry[DELAY_NR_INDICES];						// Old Alarm Active
unsigned char 	delay_forceStopFlag[DELAY_NR_INDICES];					// Force Stop Flag
unsigned char 	delay_StartFlag[DELAY_NR_INDICES];						// Start Flag
unsigned char 	delay_StopFlag[DELAY_NR_INDICES];						// Stop Flag
unsigned char 	delay_Answer[DELAY_NR_INDICES];							// Delay Answer
#pragma udata
#pragma udata DELAY_PLC2
short			delay_StartClock[DELAY_NR_INDICES];						// Clock MainZone Delay
short			delay_StopClock[DELAY_NR_INDICES];						// Clock Alarm Desactivation
short			delay_ForceClock[DELAY_NR_INDICES];						// Clock desactivacion sirena
short			delay_RepeatClock[DELAY_NR_INDICES];						// Clock desactivacion sirena
#pragma udata

void PlcInit()
{
	unsigned int i;

	for (i=0;i<ALM_NR_INDICES;i++)
	{
		old_alm_active[i] = 0;
		alm_sireneOn[i] = 0;
		mainZoneDelayFlag[i] = 0;
		mainZoneAlarm[i] = 0;
	}

	for (i=0;i<DELAY_NR_INDICES;i++)
	{
		old_delay_Entry[i] = 0;
		delay_Answer[i] = 0;
		delay_StopFlag[i] = 0;
	}
}

short GetData(unsigned char *memory, unsigned short pos)
{
	short 				data;
	STACK_POS_TYPE		datatype;
	
	datatype=pos>>IL_DATATYPE_SHIFT; 	// Segun el data type cargamos el working register

	if (datatype == IL_DATABIT) 	{	pos&=0x3FFF;	getBit(memory, pos, data);		return data>0;		}	
	if (datatype == IL_DATABYTE)	{	pos&=0x3FFF;	getByte(memory, pos, data);		return (char)data;	}
	if (datatype == IL_DATAWORD)	{	pos&=0x3FFF;	getWord(memory, pos, data);		return data;		}			
	if (datatype == IL_DATACONST)	{	pos&=0x3FFF;	return pos;											}			
	
	return data;
}

void PutData(unsigned char *memory, unsigned short pos, short data)
{
	STACK_POS_TYPE		datatype;
	datatype=pos>>IL_DATATYPE_SHIFT;
	pos&=0x3FFF;
	
	if (datatype == IL_DATABIT){		setBit(memory, pos, data);		return;		}
	if (datatype == IL_DATABYTE){		setByte(memory, pos, data);		return;		}
	if (datatype == IL_DATAWORD	){		setWord(memory, pos, data);		return;		}
//  if (datatype == IL_DATACONST) ??????????? No se ejecuta pero hay algo mal..
}

short ClockEllapsed(unsigned short clock, short clockFlag, int timeout)
{
	int data;
	
	data=clock-clockFlag;
    if (data<0) 
		data+=32678;

	if (data > timeout)
		return 1;
	else
		return 0;
}

short GetCallResult(unsigned short pos, unsigned short clock)
{
	unsigned short index;
	unsigned short cleanedIndex;

	//////////////////////////////////////////////////////
	//
	//	Variables de la alarma
	//
	unsigned char alm_active;						// Alarm Active
	unsigned char alm_mainzone;						// Main Zone Active
	unsigned char alm_zone[ALM_MAX_ZONE_NUMBER];	// Zone active
	unsigned char alm_mainir;						// Main IR Input
	unsigned char alm_ir[ALM_MAX_ZONE_NUMBER];		// IR Input
	int alm_sirdelay_high;
	int alm_sirdelay_low;
	int alm_mZndelay_high;
	int alm_mZndelay_low;
	int  alm_sirdelay;								// Sirene Delay
	int  alm_mZndelay;								// Main zone delay
	unsigned int  alm_ZoneNum;						// Zone Number
	unsigned short counter;


	//////////////////////////////////////////////////////
	//
	//	Variables del Delay
	//
	int delay_Entry;						// Entrada Delay Block
	int delay_Start_high;
	int delay_Start_low;
	int delay_Start;						// Start Delay
	int delay_Stop_high;
	int delay_Stop_low;
	int delay_Stop;							// Stop Delay
	int delay_ForceStop_high;
	int delay_ForceStop_low;
	int delay_ForceStop;					// Force Stop Delay
	int delay_Repeat_high;
	int delay_Repeat_low;
	int delay_Repeat;						// Repeat Delay

	index = pos&0x3FFF;

	// ALARM
    if (index>=ALM_FIRST_INDEX && index<ALM_FIRST_INDEX+ALM_NR_INDICES) 
    {
		STACK_GETWORD(alm_ZoneNum);     // Valor Numero de Zonas
		STACK_GETWORD(alm_mZndelay_high);    // Valor del MainZone Delay (High)
		STACK_GETWORD(alm_mZndelay_low);    // Valor del MainZone Delay (Low)
		STACK_GETWORD(alm_sirdelay_high);    // Valor del MainZone Delay (High)
		STACK_GETWORD(alm_sirdelay_low);    // Valor del MainZone Delay	(Low)

		alm_mZndelay = alm_mZndelay_high;
		alm_mZndelay <<= 8;
		alm_mZndelay += alm_mZndelay_low;

		alm_sirdelay = alm_sirdelay_high;
		alm_sirdelay <<= 8;
		alm_sirdelay += alm_sirdelay_low;

		counter = 0;
		while (counter < alm_ZoneNum && counter < ALM_MAX_ZONE_NUMBER)
		{
			STACK_GETWORD(op2);			// Valor IR Zona
			alm_ir[counter] = op2;
			counter = counter + 1; 
		}

		STACK_GETWORD(alm_mainir);		// Valor Main IR

		counter = 0;
		while (counter < alm_ZoneNum && counter < ALM_MAX_ZONE_NUMBER)
		{
			STACK_GETWORD(op2);			// Valor Zona Activada
			alm_zone[counter] = op2;
			counter = counter + 1; 
		}

		STACK_GETWORD(alm_mainzone);	// Valor Main Zone active
		STACK_GETWORD(alm_active);		// Esta activada?

		if (alm_active)
		{
			if (old_alm_active[index] == 0u)
			{
				alm_mainZoneDelayClock[index] = clock;
			}

			if (mainZoneDelayFlag[index] == 0)
			{
				if (ClockEllapsed(clock, alm_mainZoneDelayClock[index], alm_mZndelay) > 0)
				{
					mainZoneDelayFlag[index] = 1;
				}
			}

			if (alm_mzHit[index] > 0)
			{
				if (ClockEllapsed(clock, alm_desactivateDelayClock[index], alm_mZndelay) > 0)
				{
					alm_sireneDelayClock[index] = clock;
					alm_sireneOn[index] = 1;
					alm_mzHit[index] = 0;
					mainZoneAlarm[index] = 1;
				}
			}

			if (alm_mainzone > 0u && alm_mainir == 0u)
			{
				if (alm_mzHit[index] == 0 && mainZoneAlarm[index] == 0)
				{
					if (mainZoneDelayFlag[index] > 0)
					{
						alm_desactivateDelayClock[index] = clock;
						alm_mzHit[index] = 1;
					}
				}	

				if (mainZoneAlarm[index] > 0)
				{
					alm_sireneDelayClock[index] = clock;
				}
			}
			else
			{
				counter = 0;
				while (counter < alm_ZoneNum && counter < ALM_MAX_ZONE_NUMBER)
				{
					if (alm_zone[counter] > 0u && alm_ir[counter] == 0u)
					{
						alm_sireneOn[index] = 1;
						alm_sireneDelayClock[index] = clock;
					}
				
					counter = counter + 1;
				}	
			}
		}
		else
		{	
			alm_sireneOn[index] = 0;
			alm_mzHit[index] = 0;
			mainZoneDelayFlag[index] = 0;
			mainZoneAlarm[index] = 0;
		}

		if (alm_sireneOn[index] > 0)
		{
			if (ClockEllapsed(clock, alm_sireneDelayClock[index], alm_sirdelay) > 0)
			{
				alm_sireneOn[index] = 0;
				mainZoneAlarm[index] = 0;
			}
		}	

		old_alm_active[index] = alm_active;
		return alm_sireneOn[index];
	}

	// DELAY
	if (index>=DELAY_FIRST_INDEX && index<DELAY_FIRST_INDEX+DELAY_NR_INDICES) 
	{
		cleanedIndex = index - DELAY_FIRST_INDEX;
		
		STACK_GETWORD(delay_Repeat_high);
		STACK_GETWORD(delay_Repeat_low);
		STACK_GETWORD(delay_ForceStop_high);
		STACK_GETWORD(delay_ForceStop_low);
		STACK_GETWORD(delay_Stop_high);
		STACK_GETWORD(delay_Stop_low);
		STACK_GETWORD(delay_Start_high);
		STACK_GETWORD(delay_Start_low);
		STACK_GETWORD(delay_Entry);

		delay_Repeat = delay_Repeat_high;
		delay_Repeat <<= 13;
		delay_Repeat += delay_Repeat_low;

		delay_ForceStop = delay_ForceStop_high;
		delay_ForceStop <<= 13;
		delay_ForceStop += delay_ForceStop_low;

		delay_Stop = delay_Stop_high;
		delay_Stop <<= 13;
		delay_Stop += delay_Stop_low;

		delay_Start = delay_Start_high;
		delay_Start <<=13;
		delay_Start += delay_Start_low;

		if (delay_Entry > 0)
		{
			if (old_delay_Entry[cleanedIndex] == 0u)
			{
				if (delay_Start > 0)
				{
					delay_StartClock[cleanedIndex] = clock;
					delay_StartFlag[cleanedIndex] = 1;	
				}
				else
				{
					delay_Answer[cleanedIndex] = 1;
					delay_ForceClock[cleanedIndex] = clock;
					delay_StartFlag[cleanedIndex] = 0;				
				}
			}
			else
			{
				if (delay_StartFlag[cleanedIndex])
				{
					if (ClockEllapsed(clock, delay_StartClock[cleanedIndex], delay_Start))
					{
						delay_StartFlag[cleanedIndex] = 0;
						delay_Answer[cleanedIndex] = 1;
						delay_ForceClock[cleanedIndex] = clock;
					}
				}
				else
				{
					
					if (delay_Answer[cleanedIndex] > 0u)
					{
						if (delay_ForceStop > 0)
						{
							if (ClockEllapsed(clock, delay_ForceClock[cleanedIndex], delay_ForceStop) || delay_forceStopFlag[cleanedIndex] > 0u)
							{
								delay_Answer[cleanedIndex] = 0;
								delay_forceStopFlag[cleanedIndex] = 1;
								delay_RepeatClock[cleanedIndex] = clock;
							}
						}
					}
					else
					{
						if (delay_forceStopFlag[cleanedIndex] == 0)
						{	
							delay_Answer[cleanedIndex] = 1;
						}
					}
					
					if (delay_Repeat > 0)
					{
						if (delay_forceStopFlag[cleanedIndex]> 0u)
						{
							if (ClockEllapsed(clock, delay_RepeatClock[cleanedIndex], delay_Repeat))
							{
								delay_forceStopFlag[cleanedIndex] = 0;
								delay_Answer[cleanedIndex] = 1;
								delay_ForceClock[cleanedIndex] = clock;
							}
						}
					}
				}
			}
		}
		else
		{
			delay_forceStopFlag[cleanedIndex] = 0;
			delay_StartFlag[cleanedIndex] = 0;

			if (delay_Answer[cleanedIndex] > 0u)
			{
				if (old_delay_Entry[cleanedIndex] > 0u)
				{
					if (delay_Stop > 0)
					{
						delay_StopFlag[cleanedIndex] = 1;
						delay_StopClock[cleanedIndex] = clock;
						delay_Answer[cleanedIndex] = 1;
					}
					else
					{
						delay_Answer[cleanedIndex] = 0;
					}
				}
				else
				{
					if (delay_StopFlag[cleanedIndex] > 0u)
					{
						if (ClockEllapsed(clock, delay_StopClock[cleanedIndex], delay_Stop))
						{
							delay_StopFlag[cleanedIndex] = 0;
							delay_Answer[cleanedIndex] = 0;
						}
						else
						{
							delay_Answer[cleanedIndex] = 1;
						}
					}
				}

				if (delay_ForceStop > 0)
				{
					if (ClockEllapsed(clock, delay_ForceClock[cleanedIndex], delay_ForceStop) || delay_forceStopFlag[cleanedIndex] > 0u)
					{
						delay_Answer[cleanedIndex] = 0;
						delay_forceStopFlag[cleanedIndex] = 1;
					}
				}
			}
		}

		old_delay_Entry[cleanedIndex] = delay_Entry;
		return delay_Answer[cleanedIndex];
	}
	return 0;
}


/////////////////////////////////////////////////
// Executes [program] using [memory] data
// El programa en *program vine alreves... y hay que descontar
// Esto se debe a la forma en la que se llena la ROM

#define 	BASEOPCODE		(opcode&IL_BASEOPCODE)

unsigned char plc_Process(PROGRAM_TYPE *program, unsigned char *pc, unsigned char programSize, unsigned char *memory, unsigned short clock)
{
	STACK_OPCODE_TYPE	opcode;
	STACK_POS_TYPE		pos;
	unsigned short 		callResult;

	if (*pc==0u) sp=0;

	// Apuntamos el PC al principio del programa 
	if(program[*pc]!=IL_END){
		
		// Tomamos el opcode del programa
				
		opcode=program[(*pc)++];			// Tomamos el opcode
		
////////// No tiene Argumentos

		// Si cierra parentesis tomamos el opcode del stack
		if (opcode==IL_P)	{
			STACK_GETWORD(plc_Wdata);											
			opcode=STACK_GETBYTE();		// Tomamos el opcode
			STACK_PUTWORD(plc_Wdata);
			opcode|=IL_B;		
		} 

		if (BASEOPCODE == IL_MPS) 
		{
			STACK_PEEKWORD(plc_Wdata);											// Tomamos del stack
			STACK_PUTWORD( (opcode&IL_N ? ~plc_Wdata : plc_Wdata) );			// Guardamos en el stack
			return 0;
		}

		if (BASEOPCODE == IL_MPP) 
		{
			STACK_GETWORD(plc_Wdata);											// Tomamos del stack
			return 0;
		}

		if (BASEOPCODE == IL_MRD) 
		{
//			STACK_GETWORD(plc_Wdata);											// Borra
			STACK_PEEKWORD(plc_Wdata);											// Tomamos del stack
//			STACK_PUTWORD( (opcode&IL_N ? !plc_Wdata : plc_Wdata) );			// Guardamos en el stack
			return 0;
		}


////////// Tiene Argumentos

		// Si tiene B, no tiene parametros y sacamos del stack
		if ( (opcode&IL_B) ==0u ){
			pos=program[(*pc)++];		
			pos<<=8;		
			pos+=program[(*pc)++];			// Sacamos la posicion del stack

		}

		if (opcode&IL_P)					// Si tiene parentesis, metemos y pasamos al siguiente
		{
			STACK_PUTBYTE(opcode-IL_P);
			op2 = GetData(memory, pos);
			STACK_PUTWORD(op2);
			return 0;
		}


////////// Llama a funciones preprogramadas

    if (BASEOPCODE == IL_CAL) 
	{
		op3 = GetCallResult(pos, clock);	
		STACK_PUTWORD( op3 );
		return 0;
	}

////////// Empiezan con PEEK del stack

		switch(BASEOPCODE)
		{
			// cambian program counter
			
			case IL_JMP:
				*pc=pos&0xFF;							// Saltamos a la direcci�n en pos
				return 0;
			case IL_JMPC:
				STACK_PEEKWORD(plc_Wdata);								// Tomamos del stack
				if (plc_Wdata!=0) *pc=(pos&0xFF);			// Saltamos a la direcci�n en pos si tenemos un true
				return 0;				
			
			// Get data de la memoria
			
			case	IL_LD:
				plc_Wdata=GetData(memory, pos);										// Tomamos de la memoria
				
				STACK_PUTWORD( (opcode&IL_N ? !plc_Wdata : plc_Wdata) );			// Guardamos en el stack
				return 0;
				
			// Peek del stack
			
			case IL_ST:
				STACK_PEEKWORD(plc_Wdata);											// Tomamos del stack

				PutData(memory, pos, (opcode&IL_N ? !plc_Wdata : plc_Wdata));		// Guardamos en memoria
				return 0;
			case IL_S: 
				STACK_PEEKWORD(plc_Wdata);											// Tomamos del stack
				if (plc_Wdata)	PutData(memory, pos, 1);
				return 0;
			case IL_R: 
				STACK_PEEKWORD(plc_Wdata);											// Tomamos del stack
				if (plc_Wdata)	PutData(memory, pos, 0);
				return 0;
		}

////////// Empieza con get del stack


		STACK_GETWORD(plc_Wdata);												// Tomamos del stack

		if ( (opcode & IL_B) !=0u) 													// Si es B tomamos el segundo del stack
			STACK_GETWORD(op2) 
		else 
			op2=GetData(memory,pos);	



#define STOREANSWER			STACK_PUTWORD( (opcode&IL_N ? !plc_Wdata : plc_Wdata) );			return 0

		switch(BASEOPCODE)
		{
			case IL_AND:		plc_Wdata&=op2;					STOREANSWER;
			case IL_OR:			plc_Wdata|=op2;					STOREANSWER;
			case IL_XOR:		plc_Wdata^=op2;					STOREANSWER;
			case IL_ADD:		plc_Wdata+=op2;					STOREANSWER;
			case IL_SUB:		plc_Wdata-=op2;					STOREANSWER;
			case IL_CSET:		plc_Wdata=(plc_Wdata? op2 : 0); STOREANSWER;

			case IL_GT:			plc_Wdata=(plc_Wdata>op2);		STOREANSWER;
			case IL_GE:			plc_Wdata=(plc_Wdata>=op2);	STOREANSWER;
			case IL_EQ:			plc_Wdata=(plc_Wdata==op2);	STOREANSWER;
		}
	
	
		return 0;	
	} 
	return 1;
}
